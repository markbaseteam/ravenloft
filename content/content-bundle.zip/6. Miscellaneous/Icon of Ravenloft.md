---
tags: 
---

# The Icon of Ravenloft


## Description

### Icon of Ravenloft
![](https://i.imgur.com/NsXHwft.png)

Found in the Chapel in [[Castle Ravenloft]].  [[Zedifur]] attuned.