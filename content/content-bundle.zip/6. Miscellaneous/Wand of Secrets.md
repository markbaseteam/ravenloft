

![](https://i.imgur.com/BORnYsS.png)

1. Secret Doors or Traps