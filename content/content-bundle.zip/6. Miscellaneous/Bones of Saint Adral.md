
# The Bones of Saint Adral

## Description

### Bones of Saint Adral
Relics, was in the [[Vallaki#Saint Adral's Church|Saint Adral's Church]]. Taken by [[Milivoj the Gravedigger]] and solder to [[Henrik Van der Voort]] of [[Vallaki]]. Recovered by the heroes.