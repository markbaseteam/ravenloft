

![](https://i.imgur.com/pcEdl4m.png)

Found at the [[Amber Temple]]. [[Carric]] has it.
