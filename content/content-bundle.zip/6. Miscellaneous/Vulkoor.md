# Vulkoor

Vulkoor is the central god of the main cultural group of drow and scorrow in Xen'drik. Drow who worship him are referred to as Vulkoori.

## History
Some academics believe that Vulkoor is the drow interpretation of the god known as the Mockery.[1][4]

Some drow count Vulkoor as just one of many spirits worthy of worship in the natural world, and do not hold him in reverence above others.[2]
Description

Vulkoor is represented in pictures as a handsome male scorrow or as a giant scorpion.

## Dogma

The exact manner of worship depends on the customs of the individual drow tribe. Three primary forms of worship found among the Vulkoori are known. Other interpretations are valid and could be present among the drow of Xen'drik.

### Vulkoor the Hunter
The most common interpretation of Vulkoor is favored by nomadic drow. They view Vulkoor as the ultimate crafty and fearless hunter. They worship their god by being hunters who take care of themselves. They also honor him by retelling stories of his great accomplishments, and honor him through their actions.

### Vulkoor the Wrathful
The drow who follow this path see him as a vengeful, merciless god responsible for disasters including the fall of the ancient giants. They seek to appease his wrath with living sacrifices, and are eager to use trespassing adventurers for this purpose. These drow tend to be less nomadic than their brethren.[

### Vulkoor the Cunning
The drow who favor this interpretation believe the entirety of Xen'drik is theirs by right. They are xenophobic, and see outsiders as thieves seeking to rob them of their treasures. These followers search out ruins of Xen'drik to turn the relics of the past to their own ends.[1] Members of the Hantar'kul tribal tradition or "Blood Hunters" follow this path. The Qar Hantar'kul are searching the tunnels under Stormreach for weapons to use against outsiders.[2]
Myths

Scorrow worship Vulkoor, and believe themselves to be descended from a tribe of skilled drow hunters transformed by a colossal scorpion's sting. They believe this scorpion still resides in the jungles of Xen'drik, and will appear before those worthy enough to share its gifts.[5] 