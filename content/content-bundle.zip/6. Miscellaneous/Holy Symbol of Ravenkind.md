
## Description
A powerful holy symbol against undead. 


<div class="FullPage">

<!--container for image and iframe -->
<div style="float:right; margin-left:20px">
<img src="https://i.imgur.com/15Ve7RI.png" height="275" align="right"><br>
</div>

[[Zedifur]] will attune to it.

![](https://i.imgur.com/1WIl4L7.png)
