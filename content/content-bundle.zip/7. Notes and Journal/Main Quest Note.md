

Main Quest Note
![](https://i.imgur.com/ShTocBu.png)

## Readable Version
Hail thee of might and valor,

I, the Burgomaster of Barovia, send you honor - with despair.

My adopted daughter, the fair [[Ireena Kolyana]], has been these past nights bitten by a vampyr. For over four hundred years, this creature has drained the life blood of my people. Now my dear Ireena languishes and dies from an unholy wound caused by this vile beast. He has become too powerful to conquer.

So I say to you, give us up for dead and encircle this land with the symbols of good. Let holy men call upon their power that the devil may be contained within the walls of weeping Barovia. Leave our sorrows to our graves, and save the world from this evil fate of ours.

There is much wealth entrapped in this community. Return for your reward after we are all departed for a better life.

*[[Kolyan Indirovich]]

Burgomaster