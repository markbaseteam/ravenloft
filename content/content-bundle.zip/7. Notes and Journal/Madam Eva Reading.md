## The Reading

### Left Cross Card 
*This card tells of history. Knowledge of the ancient will help you better understand your enemy*
![](https://i.imgur.com/GJlQXen.png)


**Wizard - The Master of Stars** 
*Look for a wizard’s tower on a lake. Let the wizard’s name and servant guide you to that which you seek.* 

**<mark style="background: #D2B3FFA6;">Obtained</mark>**

### Top Card
*The card tells of a powerful force for good and protection, a holy symbol of great hope.*
![](https://i.imgur.com/uh6xXGB.png)
**Conjurer – 9 of Stars** 
*I see a dead village, drowned by a river, ruled by one who has brought great evil into the world.* 

**<mark style="background: #D2B3FFA6;">Obtained</mark>

### Right Cross Card
*This is a card of power of strength. It tells of a weapon of vengeance: a sword of sunlight.*

![](https://i.imgur.com/d9b4Z3M.png)
**Bishop – 8 of Glyphs** 
*What you seek lies in a pile of treasure, beyond a set of amber doors.

### Bottom Card
*This card sheds light on one who will help you greatly in the battle against darkness.*

![](https://i.imgur.com/5aT7pcl.png)
**The Darklord – King of Spades** 
*Ah, the worst of all truths: You must face the evil of this land alone!

### The Middle Card
*Your enemy is a creature of darkness, whose powers are beyond mortality. This card will lead you to him!*

![](https://i.imgur.com/VxR65fb.png)
**The Ghost – King of Hearts**
*Look to the Father's Tomb*

### Other Cards 
In case they are needed in the future
![](https://i.imgur.com/43HQCtm.png)

*The thing you seek lies with the dead, under mountains of gold coins.*

![](https://i.imgur.com/Chy5ZFQ.png)

*I see a dark room full of bottles. It is the tomb of a guild member.*
