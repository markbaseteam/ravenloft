Found at [[Van Richten's Tower]]  


#### The Tome of Strahd
![](https://i.imgur.com/csGvO1r.png)

Crest of the Zarovich family ([[Strahd von Zarovich]])

### Tome of Strahd Key Passages
I am the ancient. I am the land. My beginnings are lost in the darkness of the past.  I was the warrior, I 
was good and just.  I thundered across the land like the wrath of a just god, but the war years and the 
killing years wore down my soul as the wind wears stone into sand. 

 ll goodness slipped from my life.  I found my youth and strength gone, and all I had left was death.  My 
army settled in the [[County of Barovia|valley of Barovia]] and took power over the people in the name of a just god, but with 
none of the god’s grace or justice. 

I called for my family, long unseated from their ancient thrones, and brought them here to settle in the 
[[Castle Ravenloft]].  They came with a younger brother of mine,  Sergei. He was handsome and youthful.  I 
hated him for both. 

From the families of the valley, one spirit shone above all others.  A rare beauty who was called 
“perfection”, “joy”, and “treasure”.  Her name was [[Tatyana]], and I longed for her to be mine. 

 I loved her with all my heart.  I loved her for her youth.  I loved her for her joy. But she spurned me!  
“Old One” was my name to her – “elder” and “brother” also.  Her heart went to [[Sergei von Zarovich|Sergei]].  They were 
betrothed.  The date was set. 

With words she called me “brother”, but when I looked into her eyes they reflected another name: 
“death”. It was the death of the aged that she saw in me.  She loved her youth and enjoyed it. But I had 
squandered mine. 

The death she saw in me turned her from me.  And so I came to hate death – My death.  My hate is very 
strong.  I would not be called “death” so soon.  I made a pact with Death, a pact of blood.  On the day of 
the wedding, I killed Sergei, my brother.  My pact was sealed with his blood. 

I found Tatyana weeping in the garden east of the chapel.  She fled from me.  She would not let me 
explain, and a great anger swelled within me.  She had to understand the pact I made for her. I pursued 
her.  Finally, in despair, she flung herself from the walls of Ravenloft, and I watched everything I ever 
wanted fall from my grasp forever. It was a thousand feet through the mists. No trace of her was ever 
found.  Not even I know her final fate. 

Arrows from the castle guards pierced me to my soul, but I did not die.   Nor did I lev. I became undead, 
forever. 

I have studied much since then.  “[[Vampire|Vampyr]]” is my new name.  I still lust for life and youth, and I curse the 
living that took them from me.  Even the Sun is against me.  It is the Sun and it’s light that I fear the 
most, but little else can harm me now.  Even a stake through my heart does not kill me, though it holds 
me from movement.  But the Sword, that cursed sword that Sergei brought!  I must dispose of that 
awful tool!  I fear and hate it as much as the Sun. 

I have often hunted for Tatyana.  I have even felt her within my grasp, but she escapes.  She taunts me!  
She taunts me!  What will it take to bend her love to me? 

I now reside far below Ravenloft. I live among the dead and sleep beneath the very stones of this hollow 
castle of despair.  I shad seal shut the walls of the stairs that none my disturb me. 

### Stylized Version
![](https://i.imgur.com/vsQAsme.jpg)

![](https://i.imgur.com/IHET3QL.jpg)

