---
aliases: [plural]
tags: NPC/Strahd,Creature/Humanoid/Hag
location: Tser Falls
---
# Madame Eva

```ad-danger
Cool description
```

At [[Tser Pool]].

*Magic flames cast a reddish glow over the interior of this tent, revealing a low table covered in a black velvet cloth. Glints of light seem to flash from a crystal ball on the table as a hunched figure peers into its depths. As the crone speaks, her voice crackles like dry weeds. "At last you have arrived!" Cackling laughter bursts like mad lightning from her withered lips.*

## For [[Kas'asar Xar'Cha]] 
His tribe is at [[Castle Ravenloft]]. It is uncertain if they serve.

## [[Carric]] 
About another from Flanness

"A mighty wizard came to this land over a year ago. I remember him like it was yesterday. He stood exactly where you're standing. A very charismatic man, he was. He thought he could rally the people of Barovia against the devil Strahd. He stirred them with thoughts of revolt and bore them to the castle en masse.

"When the vampire appeared, the wizard's peasant army fled in terror. A few stood their ground and were never seen again.

"The wizard and the vampire cast spells at each other. Their battle flew from the courtyards of Ravenloft to a precipice overlooking the falls. I saw the battle with my own eyes. Thunder shook the mountainside, and great rocks tumbled down upon the wizard, yet by his magic he survived. Lightning from the heavens struck the wizard, and again he stood his ground. But when the devil Strahd fell upon him, the wizard's magic couldn't save him. I saw him thrown a thousand feet to his death. I climbed down to the river to search for the wizard's body, to see if, you know, he had anything of value, but the River Ivlis had already spirited him away."

## [[Zedifur]] 
Of the Fae.

## [[Bloodstone, Jasper]] 
From FR.

