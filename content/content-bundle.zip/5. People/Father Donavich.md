---
aliases: 
tags: NPC/Strahd, Creature/Humanoid/Human 
---
# Father Donavich

```ad-danger
Cool description
```

Writeup

![](https://i.imgur.com/htc9kq8.png)
