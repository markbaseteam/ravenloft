---
aliases: [plural]
tags: NPC/Strahd, Creature/Humanoid/Human 
location: Blue Water Inn
---
# Davian Martikov

```ad-danger
Cool description
```

At the [[Wizard of Wines]] 

![](https://i.imgur.com/uwJjsDE.png)
