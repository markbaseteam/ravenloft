---
alias: [Count Strahd, Count Zarovich]
tags: NPC/Strahd Creature/Undead Undead/Vampire
---

[![Curse of Strahd (DND 5e) - Sunday Game - The Role Play Haven - tabletop  gaming clubs](https://rphaven.co.uk/wp-content/uploads/rphaven/1631733188--event-image.jpg)1,280 × 720](https://rphaven.co.uk/games/curse-of-strahd-dnd-5e/)

![](https://i.imgur.com/xIyUMdK.png)
