---
aliases: [Baroness Lydia Petrovna, Baron Vargas Vallakovich]
tags: NPC/Strahd, Creature/Humanoid/Human 
location: Vallaki
---
# Baron and Baroness of Vallaki

```ad-danger
Cool description
```

Baroness Lydia Petrovna and Baron Vargas Vallakovich


<div class="FullPage">

<!--container for image and iframe -->
<div style="float:right; margin-left:20px">
<img src="https://i.imgur.com/d3fCuSD.png" height="275" align="right"><br>
</div>


