---
tags: NPC/Strahd, Creature/Humanoid/Human 
location: Vallaki Caskets
---
# Henrik Van der Voort

```ad-danger
Cool description
```

Paid [[Milivoj the Gravedigger]] to steal the [[Bones of Saint Adral]]. 


<div class="FullPage">

<!--container for image and iframe -->
<div style="float:right; margin-left:20px">
<img src="https://i.imgur.com/TeEuNkZ.png" height="275" align="right"><br>
</div>


