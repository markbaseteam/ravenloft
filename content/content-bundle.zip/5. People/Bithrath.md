---
tags: NPC/Strahd
---
# Bithrath
Owns Bithrath's Mercantile.
