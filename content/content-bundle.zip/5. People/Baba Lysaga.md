---
aliases: [plural]
tags: NPC/Strahd Creature/Hag
location: Berez
---
# Baba Lysaga

```ad-danger
Cool description
```

An ancient and powerful hag named Baba Lysaga lives in a hut in the middle of the village. When not in her hut, Baba Lysaga flies around in a giant skull. Baba Lysaga periodically sends her scarecrows to attack the [[Wizard of Wines]], a winery and vineyard west of [[Berez]]. 
