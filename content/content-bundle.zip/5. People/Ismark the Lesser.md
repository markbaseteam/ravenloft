---
tags: [NPC/Strahd, vibrant]
aliases: [Ismark Kolyana]
---
# Ismark the Lesser
In color :)
![](https://i.imgur.com/oSJnTLc.png)

At the [[Blood on the Vine Tavern]]

Wants to destroy Strahd. Strahd is fascinated with [[Ireena Kolyana]], his adopted sister.

His father passed a few days ago once he found out Strahd was interested in Ireena.