---
aliases: [plural]
tags: NPC/Strahd, Creature/Humanoid/Human 
location: Staint Adral's Church
---
# Father Lucian Petravich

```ad-danger
Cool description
```

Priest in [[Vallaki]], at the [[Vallaki#Saint Adral's Church|Saint Adral's Church]]. We get a really good vibe off this guy. Sayings he can protect everyone, but probably cannot truly deliver. A good guy but his faith might be challenged.

