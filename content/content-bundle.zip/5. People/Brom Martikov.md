---
tags: NPC/Strahd, Creature/Humaniod-Human  
location: Blue Water Inn
---
# Brom  Martikov

```ad-danger
Cool description
```

Child server at the [[Vallaki#Blue Water Inn]].

Insert Cool Pic