---
aliases:
tags: NPC/Strahd, Creature/Construct 
location: Abbey of Saint Markovia 
---
# Vasilka

```ad-danger
Cool description
```

A bride to be for [[Strahd von Zarovich]], made by [[The Abbott]]

![[PatchworkBirdeIMG.png|500]]