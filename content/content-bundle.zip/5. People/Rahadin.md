---
tags: NPC/Strahd Creature/Elf
location: Castle Ravenloft
---
# Rahadin

```ad-danger
An elf with brown skin and long black hair descends the wide staircase, quiet as a cat. He wears a gray cloak over black studded leather armor and has a polished scimitar hanging from his belt. "My master is expecting you," he says.
```

At the [[Castle Ravenloft]] 

Insert Cool Pic
<div class="FullPage">

<!--container for image and iframe -->
<div style="float:right; margin-left:20px">
<img src="https://i.imgur.com/pJWA80X.png" height="275" align="right"><br>
</div>


