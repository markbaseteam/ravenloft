---
tags: NPC/Strahd, Creature/Humanoid/Human
location: Blue Water Inn
---
# Yevgeni Krishkin

```ad-danger
Cool description
```

Hunter, hangs with [[Szoldar Szoldarovich]]. Met at the [[Vallaki#Blue Water Inn|Blue Water Inn]] 

![](https://i.imgur.com/7yvirTR.png)
