---
aliases: 
tags: [NPC/Strahd, Creature/Humanoid/Human, vibrant]
---
# Ireena Kolyana

```ad-danger
Cool description
```

[[Strahd von Zarovich]] is fascinated with her. Two bites!

Adopted sister of [[Ismark the Lesser|Ismark Kolyana]].

Her father passed a few days ago once she found out Strahd was interested in Ireena.

![](https://i.imgur.com/XzrI78e.png)
