---
aliases: 
tags: NPC/Strahd, Creature/Humanoid/Human
location: Amber Temple
---
# Vilnius

```ad-danger
Cool description
```

In living color. Found in [[Amber Temple]]. 

<div class="FullPage">

<!--container for image and iframe -->
<div style="float:right; margin-left:20px">
<img src="https://i.imgur.com/upj2dQk.png" height="275" align="right"><br>
</div>
