---
aliases: [Sergei]
tags: NPC/Strahd, Creature/Humanoid/Human 
location: Dead
---
# Sergei von Zarovich

```ad-danger
Cool description
```

[[Strahd von Zarovich]]'s brother, murdered by him in a love triangle with [[Tatyana]] 