---
aliases: [plural]
tags: NPC/Strahd Creature/Humanoid/Human 
location: Castle Ravenloft 
---
# Lief Lipsiege

```ad-danger
Cool description
```

In [[Castle Ravenloft]], in a study on the second floor.

Bookkeeper - has soul.
I
<div class="FullPage">

<!--container for image and iframe -->
<div style="float:right; margin-left:20px">
<img src="https://i.imgur.com/RqbjSFy.png" height="275" align="right"><br>
</div>