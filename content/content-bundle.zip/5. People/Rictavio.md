---
tags: NPC/Strahd, Creature/Humanoid/HalfElf, vibrant 
---
# Rictavio

```ad-danger
Cool description
```

Colorful. He is a bard and likes to tell tales. Says he is, like others, searching for a way out of this zone. Came with a wagon, gave a monkey to a blacksmith.

Met at the [[Vallaki#Blue Water Inn|Blue Water Inn]] 






![](https://i.imgur.com/AnKGFJC.png)
