---
tags: NPC/Strahd
---

Two very creepy kids in Barovia. The Dursts