---
aliases: [Otto Belview]
tags: NPC/Strahd, Creature/Humanoid/Mongrelman
location: Abbey of Saint Markovia
---
# Belview, Otto

```ad-danger
Cool description
```

Writeup

<div class="FullPage">

<!--container for image and iframe -->
<div style="float:right; margin-left:20px">
<img src="https://i.imgur.com/S364eEa.png" height="275" align="right"><br>
</div>