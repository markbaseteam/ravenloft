---
tags: NPC/Strahd, Creature/Humanoid/Human
location: Blue Water Inn
---
# Szoldar Szoldarovich

```ad-danger
Cool description
```

Hunter. Hangs with [[Yevgeni Krishkin]]. Met at the [[Vallaki#Blue Water Inn|Blue Water Inn]] 

![](https://i.imgur.com/Oez74uX.png)
