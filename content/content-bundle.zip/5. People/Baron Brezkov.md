---
aliases: [Burgomaster of Krezk, Anna]
tags: NPC/Strahd, Creature/Humanoid/Human 
---
# Baron Brezkov, Burgomaster of Krezk

```ad-danger
Cool description
```

Says his family built this town. Does not trust us until we bring wine. Mayor of [[Krezk]].

![](https://i.imgur.com/4JYiRbU.png)
