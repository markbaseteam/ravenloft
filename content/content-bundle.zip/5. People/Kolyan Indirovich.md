---
aliases: [Burgomaster]
tags: NPC/Strahd, Creature/Humanoid/Human , Dead
---
# Kolyan Indirovich

```ad-danger
Cool description
```

Writeup
[[Main Quest Note]]

Insert Cool Pic