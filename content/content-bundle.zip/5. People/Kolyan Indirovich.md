---
aliases: [Burgomaster]
tags: NPC/Strahd, Creature/Humaniod-Human , Dead
---
# Kolyan Indirovich

```ad-danger
Cool description
```

Writeup
[[Main Quest Note]]

Insert Cool Pic