---
aliases: 
tags: NPC/Strahd, Creature/Humanoid/Human 
location: Dead
---
# Tatyana

```ad-danger
Cool description
```

[[Strahd von Zarovich]]'s dead girlfriend. Was in love with [[Sergei von Zarovich]]. Strahd killed him, and she killed herself by throwing herself from the the heights of [[Castle Ravenloft]], but her body was never found.