---
aliases: [plural]
tags: NPC/Strahd, Creature/Humanoid/Human 
location: Saint Adral's Church 
---
# Milivoj the Gravedigger

```ad-danger
Large, and naturally grumpy.
```

Gravedigger at [[Vallaki#Saint Adral's Church|Saint Adral's Church]]


<div class="FullPage">

<!--container for image and iframe -->
<div style="float:right; margin-left:20px">
<img src="https://i.imgur.com/aITpEKY.png" height="275" align="right"><br>
</div>

