---
aliases: 
tags: NPC/Strahd Creature/Humanoid/Human 
location: Berez, by the Standing Stones
---
# Muriel Vinshaw

```ad-danger
Cool description
```

Writeup
An old crone that warns people of the dangers of [[Berez]].


