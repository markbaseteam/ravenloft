---
tags: NPC/Strahd, type
location: Vallaki 
---
# Lady Fiona Wachter

```ad-danger
Cool description
```

Family is Known servants of [[Strahd von Zarovich]], Has a house in [[Vallaki]] called [[Wachterhaus]].

Father died of heart attack. Two sons (Nicholi and Karl) and daughter Stella.

We met them at the Blue Water Inn.

<div class="FullPage">

<!--container for image and iframe -->
<div style="float:right; margin-left:20px">
<img src="https://i.imgur.com/H9b0SzE.png" height="275" align="right"><br>
</div>


