---
aliases: [Priestess of Vulkoor]
tags: NPC/Strahd, type
location: Castle Ravenloft 
---
# Alaundril Zolond

```ad-danger
Cool description
```

Writeup

Insert Cool Pic
