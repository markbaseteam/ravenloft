---
aliases: [Zygfrek Belview]
tags: NPC/Strahd, Creature/Humanoid/Mongrelman 
location: Abbey of Stain Markovia
---
# Belview, Zygfrek

```ad-danger
Cool description
```




Insert Cool Pic
<div class="FullPage">

<!--container for image and iframe -->
<div style="float:right; margin-left:20px">
<img src="https://i.imgur.com/gonJE4O.png" height="275" align="right"><br>
</div>