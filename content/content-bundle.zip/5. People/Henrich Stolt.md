---
aliases: Henrich Stolt
tags: NPC/Strahd, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: Amber Temple 
---
# Henrich Stolt

```ad-danger
Cool description
```

Writeup

Insert Cool Pic
![](https://i.imgur.com/NYWztR6.png)
