---
aliases: 
tags: NPC/Strahd, Creature/Outsider
location: Abbey of Saint Markovia
---
# The Abbott

```ad-danger
Cool description
```

A very odd person, if they are a person.

[[Abbey of Saint Markovia]]
Made [[Vasilka]]