---
aliases: 
tags: NPC/Strahd Creature/Elf-Drow
location: Castle Ravenloft, Eberron
---
# Nadus Chaulssar

```ad-danger
Cool description
```

Writeup

Insert Cool Pic
<div class="FullPage">

<!--container for image and iframe -->
<div style="float:right; margin-left:20px">
<img src="https://static.wikia.nocookie.net/sigil-city-of-doors-nwn2-persistent-world/images/7/74/Monster_Manual_5e_-_Yuan-ti_-_p307.jpg/revision/latest?cb=20160507063050" height="275" align="right"><br>
</div>