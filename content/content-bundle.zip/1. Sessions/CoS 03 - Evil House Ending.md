---
date: 2022-07-01
tags: Session/Strahd
---
# Session 3 - Evil House Ending
**Date:** 2022-07-01
**Location:**
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Nyx]] - [[Ippolito, Paul]]
- [[Zedifur]] - [[Bryan]]

## Events

### Durst Room
Looking about, we find another living quarters. Carric finds what might be a spellbook. Then screeching, then something materializes and attacks. Two creatures in tattered black robes. Based on the name of the tokens, is the parents - [[Gustav and Elisabeth Durst]]. Zedifur casts Bane on the foul creatures - Ghasts. They are foul things, reeking of death and and decay (poison). The creatures are not that effective due to the Bane. Nyx sparkle glow Eldritch Blast Gustav.

Zedifur fires off a sacred Flame, but the creature shakes it off. Kas is just not cold hearted enough with this whip. Carric whittles away at Elisabeth. The [[Ghast|Ghasts]] are having issues hitting us. Nyx hammers Gustov. 

Zed attacks Gustov, heavy damage. Elisabeth hits Carric, high damage, but avoids paralyzation. Kas misses AGAIN with the whip (a nat 1...). Carric attacks then steps aside. Gustov hits Nyx, avoids the paralysis. Nyx EB for bit damage, but not quite destroyed. 

Zed heals Nyx. Elisabeth trails Carric, drawing an attack from Nyx. Nyz misses. She rips into Carric. Kas switches to her rapier and destroys Elisabeth. Gustov misses, and Nyz nearly fumbles.

Zed goes to help Carric with his lucky rabbits paw (is it some other rabbit?!?!). Kas attempts to Compel Duel with Gustov (saves) and misses yet again with the whip. Carric Nat 20 on death save - stabilizes. Gustov misses again. Nyz hits, finishes him.

Cloak of Protection Phat Loot. Kas Snags.

### Dungeon
>[!Description]
This room is festooned with moldy skeletons that hang from rusty shackles against the walls. A wide alcove in the south wall contains a painted wooden statue carved in the likeness of a gaunt, pale-faced man wearing a voluminous black cloak, his pale left hand resting on the head of a wolf that stands next to him. In his right hand, he holds a smoky-gray crystal orb.
>
The room has exits in the west and north walls. Chanting can be heard coming from the west.

Then shadowy creatures materialize and attack!
![](https://i.imgur.com/65zCRC0.png)

Battle! Zed casts Bless. Kas strikes at one for some effect. Nyx casts lightning lure, wounding one. Kas dances about, avoiding strikes by the living darkness.

Carric strikes at one, ripping at its essence. Zed does radiant damage on one. Kas focuses on the same as Carric, further diminishing him. The shadows drain hard this round, hurting Kas and taking down Nyx. Kas is badly hurt and weak.

Carric takes one down. Zed calls down major healing. Kas turns to the one on Nyz and Zed and brings the Smite of Vulkoor, destroying it. Nyz heals since he only had 1 hp. The three remaining [[Shadow|Shadows]] continue their attacks, but Kas nimbly dances aside.

Carric steps up and strikes one of the remaining shadows. More Zed Flame but little effect. Kas wears down the one in first, but its still there. Nyx with undefined Sacred Flame damages another. Shadows counter viciously, taking down Kas and nearly turning her into a Shadow. Another takes down Carric.

Carric makes first death saves. Zed pours heal potion down Kas. Kas leaps up and skewers the shadow in front of him. Nyz casts Prot from Eeeevil.

Carric makes second death save. Zed grabs Carrics healing potion to save him. Kas destroys another, leaving one left. Nyx sacred flames the last, but fails. Shadow misses Kas.

Carric back up and strikes at the last Shadow, damaging it (crits on the off hand, but not much damage). Zed sacred flames it, heavy damage. Kas finishes, but collapses due to almost no strength.

Victory!

We get a non-magical orb. 

Note: Zed has blue sacred flame, Nyx is ....

### Reliquary and Chanters
Find all sorts of nasty evil ritual items. Then a chamber with altar. 

Chant - "he is the Ancient, he is the Land"
Carric goes to the dias, that chant goes up in volume - "one must die"

Lorgoth the Decayer, we summon thee - and something raises out of the refuse. A [[Shambling Mound]]

This thing rises up and strikes Carric. Nearly one-shots him (retcos to not so much). Kas comes over and Smites the creature. Carric tries to counter and crits it, nasty damage. Nyx eldritch blast, continues to take it down. Zed cast Bane, but the creature ignores it.

The Mound attacks Carric again and hits him. Kas finishes him off with another smite. 

We destroyed the monster in the cellar. Quest complete! We flee the house as it starts to collapse and counters. The house is revealed for the pile of offal it really is. 

Back at the crossroads.


##### Navigation
 [[CoS 02 - Evil House]]| [[Curse of Strahd]] | [[CoS 04 - 0Barovia]]

