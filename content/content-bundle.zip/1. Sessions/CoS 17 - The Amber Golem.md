---
date: 2022-11-11
tags: Session/Strahd
---
# CoS 17 - The Amber Golem
**Date:** 2022-11-11 - Veteran's Day
**Location:** [[Amber Temple]] 
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Nyx]] - [[Ippolito, Paul]]
- [[Zedifur]] - [[Bryan]]


## Events
We pick up mid-event from last time.

![[CoS 16 - Even More Amber Temple#Double Doors North]]

[[Specter|Spectors!]] appear! Carric strikes out! [[Zedifur]] casts a protection spell, then sacred flame. The angry spirits retaliate. One in particular strikes Zed hard, but he resists the drain. Nyx does get drained a bit (cannot heal that damage). Kas smites two of the spectors, destroying them. Nyx sacred flames ones.

Carric is surrounded and lashes out, slowing ripping the ectoplasm out it. Zed jumps back (no AOO!) and cases Word of Radiance, but not much. Specters strike but Carric keeps them at bay.  Kas smites two more into nothingness. Nyx Eldritch blasts. 

Carric, with Kas nearby, is able to sneak attack and destroys one, heavily damages another. Zed Word of Radiances one of the last two. Specters miss badly. Kas mops the one on Carric and bases the one on Nyx and Zed. Nyx finishes. 

These turn out to be Storm Specters.

We are pretty burnt through - long rest.

### Balcony Behind Big Statue
*This black marble balcony overhangs the northwest corner of the temple, the floor of which lies thirty feet below. Nearly half of the balcony has fallen away, and obvious cracks have formed near its ragged edge.*

This crumbling balcony may not take much weigh. Carric cautiously goes to the door with Nyx, work the doors. 

### Foyer and Obsidian Statue 
*This bare stone room consists of a foyer to the east and a shrine to the west. Candlesticks draped in cobwebs stand in the four corners of the foyer. In the shrine, a faceless obsidian statue stands in a raised alcove at the western end of the chamber. Slumped before the statue are two desiccated corpses in tattered garments. Two pairs of alcoves line the north and south walls of the shrine.*

Carric investigates. Feels a compulsion to kneel before the shrine, but he resists.  The desiccated bodies look to have been wizards. Might have died in prayer. They may have succumbed to the call. Kas provides overwatch, holding my hand crossbow all gangsta style lining up Nyx.

Zed casts Bless on himself, looks to dispel magic on the statues. He barely saves. Dispel works! We continue in. Not much with the statue. It does look like the big one. Kas gets into a city naming convention discussion with Zed.

But, there is a secret door here!

### Arrow Slit Room
*This narrow room has an arrow slit in the center of the south wall.*
Nothing.

### Secret Door 
*Hundreds of skulls fall out of a cavity behind the door. Attached to the thirty-foot-high ceiling of this dark sepulcher is an upside-down iron chest with a barrel-shaped lid.*

There is a chest secured to the ceiling, held with magic. Zed tries to dispel the arcane lock. Chest is now unlocked. Nyx unlocks, then magic washes over him, projected straight down. The center of the floor disappears - we fall to the floor below, right behind the Statue.

### Junk Room 
*The amber doors that once sealed this great stone room have been smashed, their pieces lying amid crushed bones, armor, and weapons.*

We make a grand entrance into this room from above. 

### Treasure Room
We found the treasure room off the main hall (Dispel magic)! There is our Amber Golem friend, awaiting us. Battle!

Carric readies to attack on Kas's move. Nyx -- Eldritch Blast - knocks a few bits off. Zed casts Bane on it - works! Kas "Your foul unalignedness ends today!" Vow of Emnity, Haste (a green glow) - hits with a smite. Golem amber's us, .trying to slow Carric and Kas but fails. Carric then strikes, sneak attacks and carves on it. Nyx missed. Zed guiding bold - damage. Kas his three times, inflicted heavy damage. The Golem misses both Carric and Kas. Carric  sneak attacks again - mops it up!

One pile radiates magic. In a pile of death cleric stuff - and a Sith Light Saber. The [[Sunsword]]. Carric takes it.
.
We leave with the other guy, and move on.





##### Navigation
[[CoS 16 - Even More Amber Temple]] | [[Curse of Strahd]] | [[CoS 18 - Into Castle Ravenloft]]

