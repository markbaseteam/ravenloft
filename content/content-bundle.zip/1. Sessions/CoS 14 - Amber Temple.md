---
date: 2022-10-21
tags: Session/Strahd
---
# COS 12 - TBD
**Date:** 2022-10-21
**Location:**
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Nyx]] - [[Ippolito, Paul]]



## Events
From the reading
*What you seek lies in a pile of treasure, beyond a set of amber doors.

The priest thinks its the hidden [[Amber Temple]] (X on the map) - south, 10 mile travel.

On the travels, have to go through [[Tsolenka Pass]]

### Tsolenka Pass
*The shelf of rock on which the mountain road clings grows narrow. To your left, the icy cliffs rise sharply toward dark, rolling clouds. To your right, the ground falls away into a sea of fog. Ahead, through the wind and snow, you see a high wall of black stone lined with spikes and topped by statues of demonic vultures with horned heads. Set in the center of the wall is a closed iron portcullis, behind which burns a curtain of <mark style="background: #BBFABBA6;">green flame</mark>.*

*On the other side of the dark wall, gripping the mountain's edge, is a guard tower of white stone topped by golden statues of mighty warriors.*

Nyx goes to check it out. Vulture statues crack open, [[Vrock]]s! Nyx attempts Eldritch Blast and pushes them - but fails. Kas hits one with the hand crossbow. One of the devils drops down and screeches, studding Carric. The other drop down to rake Nyx. 

Nyx counters, knocks it back against the gatehouse. Kas denouces one of them, to no avail, steps up to protect Carric. Carric is still stunned. One pours out spores, but we resist. The Vrock in a rage attacks Nyx, impotently flailing away.

Nyx strikes again, pushing him back. <mark style="background: #D2B3FFA6;">Kas DOUBLE Nat 20, double full Smite nearly kills it.....and Karric mops it.</mark>
Final Vrock is tearing into [[Nyx]] .
![](https://i.imgur.com/cvNbdfG.png)

Nyx, in bad shape, blasts again and flees. Kas engages with the whip and smites again. Carric cuts into it as well. It screeches, Carric drooling. Kas misses. It attack Kas but misses. Nyx finishes it off!

The portcullis raises, but the Green Flame is still there. Toss the Vrock into the flame, it incinerates it. It takes time, but we can navigate around the flame. 
#### Tower Lower
*A cold hearth stands across from the door, the wind howling down its chimney. A stone staircase is on the south wall. Three windows look out over a foggy sea.*
We go to the little side tower and Carric gets a barred door open with Kas' assistance. The place looks abandoned. 

#### Tower Upper
*The upper level of the tower is an icebox with windows set in almost every wall. A rusted iron ladder bolted to the floor and ceiling leads up to a wooden trapdoor. Mounted above the stone hearth is a dire wolf's head. The wind coming down the chimney howls in its stead.*

Up the stairs, its extreme cold. 

#### Top of Tower
*Ten-foot-tall, gold-plated statues stand atop the battlements, facing outward. Each one depicts a female human knight holding a lance. The cold wind stirs the snow, under which you see human skeletons clad in rusty mail.*

No heraldry.

Hole up and long rest.


*One of the statues atop this arch has crumbled, leaving only the hindquarters of the horse intact. The mountain pass continues beyond.*

Kas and Carric sees someone on the bridge, no details other than a hood. We get closer, looks a bit ring-wraithy.

*The low walls that enclose the stone bridge have fallen away in a couple of places, but the bridge appears intact. A black-cloaked rider on a charcoal-colored horse guards the middle of the bridge.*

Its [[Strahd von Zarovich]]! Then dissolves and blows away with a low evil laugh.

*The snowy pass comes to a gorge spanned by a stone bridge. At each end of the bridge is a thirty-foot-tall, thirty-foot-wide stone arch. Atop each one are two statues of armored knights on horseback with lances, charging toward one another. The wind bites and howls like wolves as it passes through the gorge.*


### Amber Temple
*The road fades away under a covering of snow, but it takes you far enough to see the facade of some kind of temple carved into the sheer mountainside ahead. The front of the structure is fifty feet high and has six alcoves containing twenty-foot-tall statues. Each statue is carved from a single block of amber and depicts a faceless, hooded figure, its hands pressed together in a gesture of prayer. Between the two innermost statues is a twenty-foot-tall archway with a staircase leading down.*

Very cold (natural weather). 

#### Into the Temple
*Icy steps descend ten feet to a time-ravaged hallway with arrow slits in the walls. Beyond the hall lies a vast, sepulchral darkness.*

#### East Arrow Slits 
*Two arrow slits are carved into the west wall of this 10-foot-high, twenty-foot-square room. Slumped in the northeast corner is a skeleton wearing a blue wizard's robe and clutching a wand to its chest.*

Nyx eyes working his way through the arrow slit but currently sees no other entrance/exit. Uses ghostly insight to try to see more. Goes in and grabs the wand, the [[Wand of Secrets]]

#### Balcony
*A twenty-foot-wide balcony of black marble with a shattered railing overlooks a vast temple. Black marble staircases at each end of the balcony descend thirty feet to the temple floor. The vaulted ceiling is thirty feet above the balcony. The walls and ceiling are covered in an amber glaze, lending the gloom a golden sheen. A set of amber doors stands closed at the west end of the balcony. A similar pair stands open to the east.*

Kas can see across the dark temple a large statue, 40' tall.

#### East Amber Doors
*This room is featureless except for a rough-edged, 10-foot-diameter circular hole in the floor to the east and empty torch sconces along the walls. Double doors of amber stand open to the north and west. A single closed door lies just south of the western set of double doors.*

Looking in the hole - Green Flame! on the floor of red marble, that opens into a room. Lots of handholds. Probably a 10' drop once down there.

We set that aside and continue to explore this level. Go to a door, nothing in it. 

#### Northern Corridor
*Glazed amber covers the walls of this twenty-foot-wide, seventy-foot-long arched corridor. The amber doors at both ends of the hall stand open. A closed door is in the middle of the east wall, and three arrow slits are cut into the wall across from it. Cracks in the black marble floor run the length of the hall.*

The arrow slits overlook the main temple complex. Carric opens the door on the East. 

#### East Bas Relief Room
*This chamber is brightly lit by red copper lanthorns that hang from the ceiling. The walls are sheathed in amber that has been shaped into bas-reliefs of wizards with spellbooks. Stairs to the north and south descend twenty feet to an obsidian lectern, behind which a slab of black slate hangs from chains. Between the stairs are descending rows of red marble benches.*

Looks like a college lecture hall. Carric notices someone trying to hide behind the lectern.  [[Vilnius]] - came with his master, there is an Amber Golem. The Flameskulls of Green Flame! killed his master. Temple is a a wealth of forbid arcane knowledge. Flameskulls are dead amber wizards. Mountain people take haven here. It does not travel far, but it does come down the hallway. Thus why the floors are cracked.


##### Navigation
 [[CoS 13 - Ruins of Berez]]| [[Curse of Strahd]] | [[CoS 15 - Amber Temple - Giant Statue]] 

