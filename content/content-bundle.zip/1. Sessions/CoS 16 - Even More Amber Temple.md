---
date: 2022-11-04
tags: Session/Strahd
---
# CoS 16 - Even More Amber Temple
**Date:** 2022-11-04
**Location:**
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Nyx]] - [[Ippolito, Paul]]
- [[Zedifur]] - [[Bryan]]


## Events
Picking up from last time, we battle a creature ([[Henrich Stolt]]) in the darkness inside the head of a giant statue.

### Head Fight
Zed leaps in and activates the [[Holy Symbol of Ravenkind]] - Sunlight. This is going to hurt Kas, but hopefully the enemy more. Zed also gets a bit of healing onto Kas. Carric, now seeing the old wizard, strikes. Kas then double hits and smites, destroying the fiend. An [[Arcanaloth]].

Loot - Spellbook, Spectacles, and Robe (magical).
[[Robe of Useful Things]] - Nyx 

There is a side room, but likely not secure. Back to a barracks for a Long Rest. Back to the giant statue. We look at a set of amber double doors. Carric cannot open it - magic. Nyx things there is necrotic magic woven in a trap. Zed looks to dispel. It seems to have worked.

### Rime Room - Catecombs
Very cold undisturbed. 
*You smell the horrid perfume of the ancient dead. Stone niches along the walls of these catacombs hold human-shaped amber husks, bones, and tattered shrouds.

*Tall, iron candlesticks stand in alcoves. Their candles ignite as you enter, casting flickering light upon the walls and causing the shattered amber to glitter.*

*More skeletal remains fill niches in the walls of this smaller annex, the amber husks that once preserved them smashed beyond repair.*

We even tried the wand, nothing of interest. Well, some of them are missing their skull. Might be the [[Flameskull]]s. We move on.

### Speaking of Flameskulls 
We go back into the main area, and there are Flameskulls ready to attack us. They are in the arrowslits overlooking the area.

Zed cast Shield of Faith on Carric and Sacred Flame on a skull (ignores cover). Kas tosses up a bolt from the hand crossbow, does cause a Shield to pop. Nyx Eldtric blast with a pull. Carric runs up and attacks one that has been pulled out by Nyz. A skull drops a small fireball between Nyz and Zed. Another toss one at Kas, who is in cover. Take some damage. The one on Carric Blurs and tries to fly away. 

Kas Misty Steps up to the balcony, but misses. Nyx attacks, misses. Carric shoots at the one on Kas. Misses. The battle continues. The Skulls are cooking Nyx. Zed puts some healing on Nyz. All three have been hit, with the one on Kas in worse shape.

A ball of green flame appears own on the main floor (flaming sphere). Two of them magic missiles Kas. Those on the lower have issues getting at the Skulls. Kas hits one, finish it off. Then Double 20 (vs Disadvantage) and crushes another. One skull left, and bases it.

Nyx Sacred Flames the last. Its about down. Carric makes a perfect climb to get up and into the arrow slit. Carric hits, and sneak attacks. Almost takes it down. It blurs and leaves. Due to Shield, we miss. It flies into the room and Zed hits it with Sacred Flame. 

Kas Misty Steps out into the area and strikes the Skull, killing the last one. She falls and twists her ankle.

### West Hall
*The walls of this twenty-foot-wide, seventy-foot-long arched corridor are sheathed in amber. The southern half of the hall is scorched by fire, and a charred corpse lies on the floor here, under a burned fur cloak. Several amber doors lead from this hall, and three arrow slits are cut into the east wall. Floating in the middle of the hall are three skulls wreathed in green flame.*

[[Staff of Frost]]

We take a short rest to catch our breath. 

### Double Doors North
*Torches in sconces illuminate a dining table in the center of the room. Covering the table is a magnificent feast that fills the hall with the rich smells of cooked meat, sweet vegetables, piping hot gravy, and wine.*

Then ghostly figures appear, and the room shows its age.

Cliffhanger!

##### Navigation
[[CoS 15 - Amber Temple - Giant Statue]] | [[Curse of Strahd]] | [[CoS 17 - The Amber Golem]]

