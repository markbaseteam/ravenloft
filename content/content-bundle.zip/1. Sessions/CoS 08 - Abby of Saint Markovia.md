---
date: 2022-08-26
tags: Session/Strahd
---
# Session 8
**Date:** 2022-08-26
**Location:**
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Nyx]] - [[Ippolito, Paul]]
- [[Zedifur]] - [[Bryan]]
- [[Bloodstone, Jasper]] - [[Lonnie]] 

## Events
Headed to [[Krezk]] with a wagon full of wine. Level up! Kas gets her mount - its a giant scorpion that she "merges with" to ride. On the road we meet [[Bloodstone, Jasper|Jasper]]. 

### Krezk 
Arrive in Krezk, present the wine and enter. There is not much in the way of business - its share and share alike. Its around noon after all our endeavors of the day. Most people are gray.

Note that the baroness looks sad, maybe in mourning. Her son died several days ago. There are 4 graves behind her house, one is a fresh grave. All of her children die of some strange illness. In the broader family plot, it looks like others dug up and reburied, but the graves did not settle correctly. Zed consoles and blesses. 

### To the Abby!
Winds up a large hill that overlooks the town. 

*The switchback road that hugs the cliff is ten feet wide and covered with loose gravel and chunks of broken rock. The ascent is slow and somewhat treacherous, and the air grows colder as one nears the top.*


### To the Pool First!
[[Ireena Kolyana]] stops about 100 feet. She sees:

*Even under gray skies, this pool at the north end of the village shimmers and sparkles. Near its shore sits an old gazebo on the verge of collapse. A wooden statue of a mournful, bare-chested man, its paint chipped and faded, stands in the gazebo with arms outstretched, as though waiting to be embraced.*

The pool radiates vibrancy. She wants to go back down to it. The pool is very positive effects. The world feels less gray and oppressive. Ireena begins to walk with a purpose to the water.

*As Ireena reaches the pool's edge, an image appears in its sparkling blue waters: a handsome youth of kind and noble visage. The sadness in his eyes turns to sudden joy.

*"Tatyana!" he says. "It has been so long! Come, my love. Let us be together at last."*

*Ireena gasps and puts a hand on her heart. "My beloved Sergei! In life, you were a prince and a man of faith. We were to be married long ago. Has this blessed pool called your spirit to me?" She reaches toward the water's surface as a hand of water rises up to take hers.*

Jasper tackles here, Kas does not sense evil. Then there is a peel of thunder. A cloud roles in, with a face in it. "She is mine!" And that hand shoots down a lightning bolt into the pool. We are knocked to the ground and the gazebo is destroyed, including the shrine.

*A peal of thunder shakes the land, and the dark clouds coalesce into a terrible visage. A deep, dark voice from beyond the mountains cries out, "She is mine!" A terrible crack resounds as blue lightning splits the sky and strikes the pool.*

Ireena does not get what just happened, does not know the names. But [[Ismark the Lesser]] confirms the face in the storm was [[Strahd von Zarovich]].

Rest of the town hid.

### Back to the Abby
The [[Abbey of Saint Markovia]]. 

*The road from the village climbs above the mist to the wide ledge on which the abbey is perched. A light dusting of snow covers the trees and the rocky earth.*

*The gravel road passes between two small, stone outbuildings, to either side of which stretches a five-foot-high, three-foot-thick wall of jumbled stones held together with mortar. Blocking the road are iron gates attached to the outbuildings by rusty hinges. They appear to be unlocked. Viewed through the gates, the stone abbey stands quiet. Its two wings are joined by a fifteen-foot-high curtain wall. A belfry protrudes from the rooftop of the closer north wing, which also sports a chimney billowing gray smoke.*

Note the most defensive place. We enter.
*Stunted pine trees grow out of the rocky earth in the graveyard near the foundation of the abbey's north wing. The windows of the structure are cracked panes of leaded glass. Ancient gravestones burst from a thin crust of snow in the yard. Beyond the low wall that surrounds the graveyard, the ground falls away. The village lies four hundred feet below, and the view is breathtaking.*

Has hears snoring from the tower. Stealths over, couple of poor sentries. Moving on. But, two mongrel men awake at Zed's noise.  [[Belview, Otto]] and [[Belview, Zygfrek]]. They lead on.

*The thick fog that fills this courtyard swirls, as if eager to escape. The courtyard is surrounded by a fifteen-foot-high curtain wall on which stand several guards with their backs to you - or so it seemed at first. It's clear now that these guards are merely scarecrows.*

*Wooden doors to the north and east lead to the abbey's two wings. In the center of the courtyard is a stone well fitted with an iron winch, to which a rope and bucket are attached. Along the perimeter, tucked under the overhanging wall, are several stone sheds with padlocked wooden doors, as well as three shallow alcoves that contain wooden troughs. Two wooden posts pounded into the rocky earth have iron rings bolted to them, and chained to one of them is a short humanoid with bat wings and spider mandibles.*

*The quiet is shattered by horrible screams coming from the sheds.*

Ireena has second thoughts after the mongrelmen, and it gets worse. Two people come out - one a handsome and a woman. He notes its an opportunity for the woman to interact with "others". She has seams along her shoulders and legs. She is rather stitched together. A [[Golem, Flesh|Flesh Golem]]. She is to a bride for Strahd.

Quest - A bridal gown! We decline and he is not pleased. 

### Back to the Town
Talking with the [[Baron Brezkov]]. All of a sudden that [[The Abbott]] is there telling the Baron that he will raise their son if he gets a wedding gown within a month. The mother agrees. Carric confronts to make sure that there son would be whole.  

As Anna (Baroness) prepares, others call for Anna to help give birth nearby. A baby is born, has the gray look. Very sad, the child has no soul. Zed gives a look on a spiritual level - the grays do not have souls!

Note that the Brezkov's do not know [[Tatyana]] or [[Sergei von Zarovich]] 

## Vallaki 
We will provide protection for [[Baron Brezkov|Anna]] to [[Vallaki]]. In return, she will provide us more information about the lands.

Anna's Information 
- Souls do not leave, reincarnate
- Many born without souls
- Strahd is a vampire, and cursed of the land. Has classic vampire tropes. Family cursed by some foul deed in the past.
- Many draw, all eventually die.
- Werewolves and dire wolves, plus bats
- Time is in moons, vs months.
- Wine is the lifeblood of [[Barovia]] 
- An outsider near [[Mount Baratok]]
- Gods - Morninglord, but absent
- Mother Moon - has cursed people with Strahd.
- Vistani - serve Stahd.
- Walk of the dead to the castle at night
- Never harm a Raven
- The Abbott has been around for a century. Many believe he serves Strahd. Thanks [[Father Donavich]]. 

##### Navigation
[[CoS 07 - Battle of the Blights]]  | [[Curse of Strahd]] | [[CoS 09 - The Bones of Saint Adral]]

