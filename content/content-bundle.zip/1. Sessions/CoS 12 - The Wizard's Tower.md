 ---
date: 2022-09-30
tags: Session/Strahd
---
# CoS 12 - The Wizard's Tower
**Date:** 2022-09-30
**Location:**
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Nyx]] - [[Ippolito, Paul]]
- [[Zedifur]] - [[Bryan]]
- [[Bloodstone, Jasper]] - [[Lonnie]] 

## Events
Montage to discover the wizard's tower. Its to the west. As one nears it, it cuts of magic and patrons.

Tower door. [[Van Richten's Tower]]

### Entrance
*The tower door is made of iron, with no visible handles or hinges. In the middle of the door is a large, embossed symbol - a connected series of lines with eight stick figures set around it. Carved into the lintel above the door is a word: KHAZAN.*

![](https://i.imgur.com/7fa4QOk.jpg)

We sing and dance the YMCA song. It opens.

*Also, Rotting wooden beams support the scaffolding, which groans and creaks with the slightest breeze. A series of ladders and platforms lead to a hole in the northwest wall on the third floor.*

Inside, there are statues and chains. Figure out its a lift. Second floor is rotted, probably the third as well. Since Kas does not know numbers above 3, going to 4 a magical experience.

### That Floor Above Three
*Unlike the levels below, this room shows signs of recent habitation, and although the place reeks of mold and mildew, it has plenty of creature comforts, including a cozy bed, a desk with matching chair, bright tapestries, and a large iron stove with plenty of wood to feed it. Light enters through arrow slits as well as through dirt-caked windows with broken shutters. Other features of the room include a standing suit of armor and a wooden chest. Old wooden rafters bend under the weight of the tower roof, which has somehow remained intact. Mounted to the rafters are pulleys around which hang iron chains that support the tower's elevator platform.*

Carric things someone took meaningful items from here. The chest appears be an under mimic. Carric opens - a wax severed head of a Vistani (real but waxy). A book is underneath.

![[Tome of Strahd#The Tome of Strahd]]

Note - that armor is freestanding. 

### The Wagon
Since the Vistani is dead, we examine the wagon. Carric picks the lock on the wagon but misses the trap. There is an explosion. We all get blown back, Nyx is charred. Zedifur saves him. Its a painful lesson. We take a short rest to shore ourselves back up.

### On the Road
Take the book to open back in [[Vallaki]]. But on the way, we are attacked by [[Wolf|Wolves]] wolves and [[Werewolf|Werewolves]].

The group take a round to get in each other's range, and call upon various magics to be ready. The werewolves may be a problem - not much magic weapons or silver in the group. Focus on the wolves first. There is a terrible crash as all come together. Wolves start to go down, but a couple of werewolves are breaking through to the back line. The wolves are thinned, now the real fight starts.

Kas does call upon [[Vulkoor]] to root one of the werewolves to the spot as a sub-prime hunter (Channel Divinity). The casters are damaging the other werewolf. Jasper switches to his magic mace to attack one of the werewolves and gathers up for a second wind. Carric is a dodging fool. Zed and Nyx take on werewolf down. Kas turns and smites one werewolf (crit), and finished it. The battle turns, victory.

Do not recognize the dead werewolves. 

![[Tome of Strahd#Tome of Strahd Key Passages]]




##### Navigation
[[CoS 11 - Castle Ravenloft]] | [[Curse of Strahd]] | [[CoS 13 - Ruins of Berez]]

