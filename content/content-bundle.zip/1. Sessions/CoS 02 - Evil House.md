---
date: 2022-06-24
tags: Session/Strahd
---
# Session 2 -  Evil House
**Date:** 2022-06-24
**Location:**
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Zedifur]] - [[Bryan]]

## Events
### Retro scene
Back in the woods with Zedifur catches the scent of death, rotted human flesh.  The foul scent leads you to a human corpse half-buried in the underbrush about fifteen feet from the road. The young man appears to be a commoner. His muddy clothes are torn and raked with claw marks. Crows have been at the body, which is surrounded by paw prints. The man has obviously been dead for several days. He holds a crumpled envelope in one hand.

![](https://i.imgur.com/ShTocBu.png)


Its a red herring - this is trying to throw us off the scent.

### Back to the House
#### Angry Spectral Woman
Exploring the dusty third floor. Kas finds a linen closet and takes some soap. Find another room with stain glass with a forest theme. Perhaps a door to a nursery. Carric opens the door, there is shroud. Behind us, a woman manifest and screams. And she attacks!

![](https://i.imgur.com/iCFbVLN.png)

Zedifur calls upon his goddess to bring down a sacred flame, but it steps aside. She cries about someone taking her baby! She rushes forward to strike at Carric with an icy touch. Kas moves to better position to strike and hits, but a lessened effect. Carric strikes with his quick blades, doing some damage. 

Zedifur again with the sacred flame, but again misses. The woman turns and, being a bitch, her icy touch burning Kas (but Kas wards off some further foul effect). Kas counters with another piercing attack. Carric continues to rend into her. 

Zedifur finally connects with his god, burns her up!

#### Into the Nursery
There is a tightly wrapped baby sided bundle. Carric touches the bundle and whatever was inside collapses into dust. Nothing else in the room.

#### Bedroom
Kas finds a secret door to the attic and weird eyes in the woodwork.

#### Attic
While empty, it appears to have been a living space. One door is locked with a padlock. Kas unlocks.

This room contains a bricked-up window flanked by two dusty, wood-framed beds sized for children. Closer to the door is a toy chest with windmills painted on its sides and a dollhouse that's a perfect replica of the dreary edifice in which you stand. These furnishings are draped in cobwebs. Lying in the middle of the floor are two small skeletons wearing tattered but familiar clothing. The smaller of the two cradles a stuffed doll that you also recognize.

Kas calls Zedifur into see if there is anything to be done with the two bodies. Zedifur picks up the doll, and we see [[Rose and Thorn]] materialize. Thorn - "don't touch my toy." We learned they got locked away to protect from the monster (in the basement). But Carric and Zedifur that they are not the same as the ones in the front of the house. Those had "tricky kids" attitude, these are sad.

Rose points to the secret door here in the attic. They direct us to it. Zedifur takes the doll. Rose leaps at Carric and possess him (adds a flaw - In Charge). Zedifur gets Thorn (scared). But they resist them. 

Another room with sheets over stored furniture. Kas finds as chest, there is a sheet with blood. There are bones, its a skeleton of a woman. There is a dress is similar to the spectre. 

Kas, with her fashion sense, this might be the nursemaid. The plot thickens.

**Ding! Level 2!**

Secret door down to the lower levels. Very much a death motif down here. More of a crypt vibe. Very gothic. At a crossroads, we might have found actual crypt. Then there is an antechamber, table and bones scattered about.

Kas does not sense any supernature nearby. But was we look around, a Grick attacks Carric from the top of an alcove.

![](https://i.imgur.com/aeGlLnF.png)
 
 Carric attacks the foul thing, damaging it. Its squishy.  He then deftly moves away. The Grick attacks Carric. It mauls Carric, taking him down. Zenifur calls on [[Mishakal]] to get Carric back on his feet.  Kas fumbles a bit getting her whip out as she jumps up on the table.
 
 Carric stabs at the foul thing and moves back. The Grick starts to follow but strikes at Kas, rending with its foul tentacle. Zedifur strikes with Guiding Bolt, damage, lighting it up. Kas misses, despite Advantage due to crappy d20s.
 
 Carric pulls out a shortbow to strike the beast. Misses, the grick misses as well. Zedifur calls on Scared Flame, finishes the foul beast. We rest (long).
 
 
 Continuing, there is a rising sound of chanting. Then 2 creatures claw there way up out of the dirt of the tunnel. Ghouls!
 
 ![](https://i.imgur.com/tSbuqwV.png)

Zedifur calls on Mishakal to repel these foul creatures. One flees from the searing light. The other slathers forward. Carric steps aside to ready an action, then attacks the ghoul as it rushed forward to attack the ghoul. A critical hit! Lots of dice. One-shot kill. Kas advances quietly, following the other ghoul. Casts Shield of Faith on herself.

Zedifur follows. Carric does poke his head in another room, interesting stuff.

This room is festooned with moldy skeletons that hang from rusty shackles against the walls. A wide alcove in the south wall contains a painted wooden statue carved in the likeness of a gaunt, pale-faced man wearing a voluminous black cloak, his pale left hand resting on the head of a wolf that stands next to him. In his right hand, he holds a smoky-gray crystal orb.

The room has exits in the west and north walls. Chanting can be heard coming from the west.

Then follows. 

Kas rushes forward, striking the ghoul. Zedifur advances and sacred flame. Damage building up on the ghoul. Carric arrives, jumps up on the table and strikes - hits, and kills it.

End of session.




##### Navigation
 [[CoS 01  - Into Barovia]]| [[Curse of Strahd]] | TBD

