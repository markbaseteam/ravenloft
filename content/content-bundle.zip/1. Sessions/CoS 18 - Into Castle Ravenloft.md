---
date: 2022-12-09
tags: Session/Strahd
---
# CoS 18
**Date:** 2022-12-09
**Location:**
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Nyx]] - [[Ippolito, Paul]]
- [[Zedifur]] - [[Bryan]]

## Events
We have the book, the sword, the icon and our souls. Time to take down [[Strahd von Zarovich]]. To [[Castle Ravenloft]]!

Do we take [[Ireena Kolyana]], who Strahd thinks is [[Tatyana]]? Group whines about morality. 

We make wooden stakes. Stay near Zed has the Icon has Protection from Evil running within 30'.

### The Crypts
Into the Castle. Mist and dread hang in the air. New statues of dragons. We continue to the Chapel of Ravenloft, and seek a way into the crypts. We find a circular stair, one headed down. Deep into the castle the stairs take us - the Crypts. Hear [[Vistani]] up ahead. Chat with them, they are stalling for [[Rahadin]] to show up. Softly, Kas hears faint shout of rage, frustration. Kas is very blunt about why the group is here.- 

Sumbitch attacks!
![](https://i.imgur.com/VKWMoZg.png)

Rahadin misty steps to Kas and Carric. Rapid strikes on Kas and Carric. One Vistani casts Evil Eye on Carric - Held! Kas shakes off the Eye. Others attack. Wear on us. Kas hits and Smites him twice, calling her Vow of Emnity. Nyx misses. Carric breaks out of the Eye. Zed casts Shield of Faith on Kas and Bane on the enemy, but that has no effect. 

Rahadin moves to Nyx and Zed - Zed gets the extra attack. Hard hit on Zed and Nyx. Thugs his Carric once. Others hit Kas. Kas tears into a thug, wounding him badly. Nyx blasts Rahadin - badly wounded. Carric rips up a thug, kills him. Zed hopes down and heals Kas and Shield of Faith on Carric.

Rahadin, with dark energy on the blade, strikes Nyx and Zed. Nyx takes it rather bad. Carric dodges most of the attacks. Kas steps over and tears more into Rah. Nyx puts more damage on him. Carric slips the Thugs and attacks Rahadin. Sneak attack takes him down. The thugs continue on. Zed heals Nyx.

Vistani come one, fanatical. Carric takes some damage. Others miss Kas except for a glancing blow. Kas hits hard, nearly killing a thug, Nyx finishes. Carric carves into a thug. Zedifur calls on Sacred Flame , injuring another. 

Thugs hit Carric, Kas dances away. Kas pours more damage on a wounded thug but does not quite take them down. Nyx mops the wounded thug. Two left. Nyx futher hurts the other wounded thug. Carric nearly takes down the wounded thug, but does not finish him. Zed sacred flames the wounded. 

Last thug misses Kas, Kas tears into him and the rest finish him. 

### Strahd
End game!

![](https://i.imgur.com/xIyUMdK.png)

He monologues a bit, and the fight is on. Strahd throws out a dark necrotic bold, injuring Nyx. Kas rushes forward as a blur, but misses. Strahd tries a quick counterattack but misses. Carric pulls out the Sunsword and rushes Strahd, "[[Sergei von Zarovich|Sergei]] sends his regards". Carric hits him, but Strahd hits back hard. Nyx "just blast him". Strahd misses with another strike. Zed heals Carric via the Icon and Spiritual Weapon. 

Strahd is effected by the Sword, it burns him. He focuses his wrath on Carric. He backhands Carric, nasty damage. He then grabs Carric and tries to bite him. Carric is able to turn partially away. Kas injects healing poison (lay on hands) to Carric and then strikes Strahd pretty hard even though the light is hurting her eyes. Carric attempts to wriggle out of Strahd's grasp. but fails. Nyx tosses out a few items from the bag of useful items (animals to attack). Zed pulls out the [[Holy Symbol of Ravenkind]] and more Sunlight. Then the dogs strike - one knock Strahd down! That keeps him there, taking Radiant Damage. 

Strahd strikes the dogs, killing them easily. Kas strikes and hits two time even with the Light, heavily hurting him. Carric escapes from Strahds grasp and snags a potion. Stradh fails about between out strikes, the light hurting him. Nyx draws guiding bolt and hits. Zed calls down Flame Strike!  

![](https://i.imgur.com/DKH8xSe.jpg)


Big Explosion of Light 

### Epilogue
Carric - on Strahd's throne
Zed - in the wildfey with carrots
Nyx - in the fey - might be nasty going on - eyes back to the same color (what happened to patron)
Kas - Back to Eberron, the mist fades and some of the tribe has return.

There is a dark soft laugh. But someone steps into view.









##### Navigation
 [[CoS 17 - The Amber Golem]]| [[Curse of Strahd]] | TBD

