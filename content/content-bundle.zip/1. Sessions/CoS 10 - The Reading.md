---
date: 2022-09-16
tags: Session/Strahd
---
# Session 10 - CoS
**Date:** 2022-09-16
**Location:** [[Vallaki]]
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Zedifur]] - [[Bryan]]
- [[Bloodstone, Jasper]] - [[Lonnie]] 

## Events 
After delivering the bones, the church looks to be a good place for [[Ireena Kolyana]] to stay (sanctified). 

Go to the Blue Water Inn for dinner then back to the church overnight. [[Baron Brezkov|Anna]] arrives, she is not doing well in finding a dress. The [[Baron and Baroness of Vallaki|Baroness Lydia Petrovna]] supposedly has one. [[Rictavio]] comes down and chats.

[[Lady Fiona Wachter]], to the north of the Inn, has an opportunity for us. We might check it out the next morning. Afterward, [[Rictavio]] comes back and notes that the Wachter family are servants of [[Strahd von Zarovich]], 

**To [[Wachterhaus]]** 
*This house seems disgusted with itself. A slouching roof hangs heavy over furrowed gables, and moss-covered walls sag and bulge under the weight of the vegetation. As you study the house's sullen countenance, you hear the edifice actually groan. Only then do you realize the extent to which the house hates what it has become.*

Meet with the Lady. She is a caricature of a villain. She makes small talk. She is looking for regime change in Vallaki. Too many frivolous celebrations. Need people to get back to work and work for The Man (Strahd). Basically get more noticed and attention from Strahd. As the purest bloodline, she would rule.

Book club of evil is in. We give vaguebook answer.

## To the [[Tser Pool]] 
The [[Vistani]] and [[Madame Eva]] 

![[Madam Eva Reading]]

Ask about the wedding dress - the [[Baron and Baroness of Vallaki|Baroness Lydia Petrovna]]

## Leaving the Pool:
*Even here, in the mountains, the forest and the fog are inescapable. Ahead, the dirt road splits in two, widening toward the east. There you see patches of cobblestone, suggesting that the eastern branch was once an important thoroughfare.*

*Parked at the fork in the road, pointed east, is a large black carriage drawn by two black horses. The horses snort puffs of steamy breath into the chill mountain air. The side door of the carriage swings open silently.*


![[Pasted image 20220916223620.png]]

##### Navigation
[[CoS 09 - The Bones of Saint Adral]] | [[Curse of Strahd]] | [[CoS 11 - Castle Ravenloft]]

