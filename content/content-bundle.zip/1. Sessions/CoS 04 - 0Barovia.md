---
date: 2022-07-22
tags: Session/Strahd
---
# Session 4 - Barovia
**Date:** 2022-07-22
**Location:**
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Nyx]] - [[Ippolito, Paul]]
- [[Zedifur]] - [[Bryan]]

## Events

![](https://i.imgur.com/ykSkMDY.jpg)

Explore a bit. Learn about [[Strahd von Zarovich|Count Strahd]].

### Blood on the Vine
[[Blood on the Vine Tavern]].
- [[Ismark the Lesser]] says that some of Drow. About 3 weeks ago (away from home village for 3 weeks, explore 1 week before entering the mist) 
- Wants to destroy [[Strahd von Zarovich]] and save his sister [[Ireena Kolyana]]. She is not at the castle yet, but has been "visited"
- Killed his father.

There is one house with a wailing woman who lost her child.


### Burgomaster Masion
To the [[Burgomaster Mansion]] house. We will help take the body to the church to do a service them bury. Then we will take the sister to [[Vallaki]].

### Church
Top a slight rise, against the roots of the pillar stone that supports [[Castle Ravenloft]], stands a gray, sagging edifice of stone and wood. This church has obviously weathered the assaults of evil for centuries on end and is worn and weary. A bell tower rises toward the back, and flickering light shines through holes in the shingled roof. The rafters strain feebly against their load.

The heavy wooden doors of the church are covered with claw marks and scarred by fire.

The doors open to reveal a ten-foot-wide, twenty-foot-long hall leading to a brightly lit chapel. The hall is unlit and reeks of mildew. Four doors, two on each side of the hall, lead to adjacent chambers.

You can see that the chapel is strewn with debris, and you hear a soft voice from within reciting a prayer. Suddenly, the prayer is blotted out by an inhuman scream that rises up from beneath the wooden floor.

The chapel is a shambles, with overturned and broken pews littering the dusty floor. Dozens of candles mounted in candlesticks and candelabras light every dusty corner in a fervent attempt to rid the chapel of shadows. At the far end of the church sits a claw-scarred altar, behind which kneels a priest in soiled vestments. Next to him hangs a long, thick rope that stretches up into the bell tower.

From beneath the chapel floor, you hear a young man's voice cry out, "Father! I'm starving!"

[[Father Donavich]] - claims his son is now a spawn of Strahd. But the Morninglord has not answered. He had gone up to destroy Strahd and he turned him. A blackrobed wizard from a foreign land that put him up to it (wizard now dead)

Iveena was found new the pillarstone of Ravenloft, no memory of her past as a girl. 

Oh, and spirits of heroes from afar right up and march to Castle at midnight.

Doru, his son.

An eerie green light suffuses the graveyard. From this light emerges a ghostly procession. Wavering images of doughty women toting greatswords, woodwise men with slender bows, dwarves with glittering axes, and archaically dressed mages with beards and strange, pointed hats - all these and more march forth from the graveyard, their numbers growing by the second.

We survive the night, the father to be buried. 

Father offers another location - an Abby in [[Krezk]].



##### Navigation
[[CoS 03 - Evil House Ending]] | [[Curse of Strahd]] | [[CoS 05 - On the Road]]

