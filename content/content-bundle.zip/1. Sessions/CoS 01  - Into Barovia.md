---
date: 2022-06-17
tags: Session/Strahd
---
# Session 1
**Date:** 2022-06-17
**Location:** 
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Nyx]] - [[Ippolito, Paul]]
- [[Zedifur]] - [[Bryan]]

## Events
In the dead misty forest. We all meet. Zedifur and Kas bond over divinities. Carric and Kas are wary of each other. Then a fairy lying in the road. 

We establish that the number 3 is the most important.

Continue on the road.

![](https://i.imgur.com/q48QGbK.png)

Perhaps we are not so far from the land of giants. Through the gates is a village. In the distance on the cliffs is a large gothic castle. 



### Barovia
The village is named [[Barovia]]. This architecture is not familiar. There are two small children, pallid/washed out. 

### Rose & Thorn
![](https://i.imgur.com/mnn5VuZ.png)

After shushing the boy, the girl turns to you and says, "There's a monster in our house!" She then points to a tall brick row house that has seen better days. Its windows are dark. It has a gated portico on the ground floor, and the rusty gate is slightly ajar. The houses on either side are abandoned, their windows and doors boarded up. Names are [[Rose and Thorn]]

There is some monster in the house. Come saves us. The mists push us that way. From afar, the house looks dilapidated. As we approach, it appears better. Odd.

Golden windmill on stoneyfield. Odd shield. Panes of stain glass. Portraits of nobility. There are woodland scenes that do not appear as we saw them. The kids hand outside, but Carric sees then fade as the door slams shut. We cannot open the doors. We continue into the house.

There is a longsword over the mantle with a windmill engraved. A number of rooms and a stair up. There are foul creatures weaved in the walls instead of vine motif.

Dining room - Alpine vale painting. Hunting motif. Set up for dining, but no food. Carric rings the servant bell but no answer. Still more underlying motif.

Tidy kitchen. Food and a dumbwaiter. A parlor with a stags head. Three stuffed wolves. A nice den. One cabinet has a few game items. But the other has weapons (crossbows)

### Second Floor
A hallway lined with armor. Portraits of the family, but the youngest does not appear to be loved.

One set of double doors to an office - find an iron key.

Red velvet drapes cover the windows of this room. An exquisite mahogany desk and a matching high-back chair face the entrance and the fireplace, above which hangs a framed picture of a windmill perched atop a rocky crag. Situated in corners of the room are two overstuffed chairs. Floor-to-ceiling bookshelves line the south wall. A rolling wooden ladder allows one to more easily reach the high shelves

The conservatory - instruments (harpsichord, harp).

Carric burns some ashes in one place, leaves, comes back and its clean again.

### Third Floor
This floor is dusty and with cobwebs. Stepping forward, the armor animates! Zedifur calls upon  Mikasha, providing us a blue glow of protection. The foul armor misses Kas. Nyx glides up and hover, striking the armor with Eldridic Blast. Carric and Kas engage the armor but both miss. 

Zedifur fires a crossbow and hits with a crit, damaging the armor. The armor does strike a glancing blow to Kas. Nyx misses as he still trying to get the hand of these new powers. Karric and Kas miss.

Zedifur pulls down sacred flame onto the armor. The armor misses Kas. Nyx finishes it with more sacred flame.

Kas catches her breath, recovers.

Looks to be the lord/lady bedroom, dusty. There is a jewelry box with a few items of value.

### For next time 
Why is it dusty up here and not the rest of the house?




##### Navigation
 | [[Curse of Strahd]] | [[CoS 02 - Evil House]]

