Eva---
date: 2022-09-09
tags: session\strahd
---
# Session 9
**Date:** 2022-09-09
**Location:** [[Vallaki]] 
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Zedifur]] - [[Bryan]]
- [[Bloodstone, Jasper]] - [[Lonnie]] 

## Events

### On the Way to Vallaki 
There are 4 [[Vistani]] as we approach an intersection near the [[Luna River]]. They are waiting for us. [[Madame Eva]] of the [[Tser Pool]].

The Kolyana's have a surprised reaction (kinda like famous person asking you over). We plan to take the Kolyana's to [[Vallaki]] and then to the Pool. Perhaps we can learn something about leaving this place.

### Vallaki 
[[Festival of the Blazing Sun]] is going on in the town square. [[Baron Brezkov|Anna]] says there is always a festival in Vallaki - they foolishly think that such joviality staves off [[Strahd von Zarovich]].

#### Saint Adral's Church 
Stop in at [[Vallaki#Saint Adral's Church|Saint Adral's Church]]. [[Father Lucian Petravich]]. We really know this guy (Insights of 19, 21, and 27).

New Quest - Someone stole the Bones of Saint Adral. The priest confides this to Zed. The priest thinks [[Milivoj the Gravedigger]] took the bones. He is very temperamental. 

Zed confronts Milivoj with Kas providing backup. He admits it. He sold bones [[Henrik Van der Voort]] to get food for his family. Henrik did ask in round about ways for Milivoj to dig up bodies in the past but he has refused. The man is in town.

Zed makes him go confess to the priest. Priest is moved by the story and is merciful, and wants to help his family. But he is disturbed by what has happened to the bones.

Priest feels Henrik is evil.

#### Coffinmaker
We pass a procession with most of the townfolk forcing their enthusiasm. Then to the shop.

*This uninviting shop is two stories tall and has a sign shaped like a coffin above the front door. All of the window shutters are closed up tight, and a deathly silence surrounds the establishment.*

We are at the back door but do not hear anything. Its barred from the inside. Eventually we force the front door as Henrik will not lets us in. Kas intimidates him, and he will lead us to the bones upstairs.

Upstairs, Henrik says to go right. Kas, being not so bright, opens the door on the left. There is an foul creature there, somewhat drow like, and Kas comes forward. Its throws Kas off (first is a crit/fail, Inspiration, Hit and smite for near minimal damage). Henrik attacks Carric on the stairs, but not much effect. Zed takes Henrik out with Sacred Flame.

The foul [[Vampire Spawn]] attacks, raps up Kas, and bit her! Carric rushes in and stabs the spawn. Kas breaks out and her weapon bursts into a green flame. Zed casts Guilding Bolt, hits it and granting Advantage. Attacks Kas and grapples again, but fails to bite. Carric attacks, misses with the rapier but hits with the dagger with good damage (partially resisted). Kas attacks but misses. Zed drops Sacred Flame, misses. Casts Shield of Faith on Kas. The creature also starts to heal. 

Kas finally puts a bit hit on the Spawn. Zed hits again, causing damage and Advantage. Carric finishes that spawn of darkness.

We find the bones and minor loot. 


##### Navigation
[[CoS 08 - Abby of Saint Markovia]] | [[Curse of Strahd]] | [[CoS 10 - The Reading]] 

