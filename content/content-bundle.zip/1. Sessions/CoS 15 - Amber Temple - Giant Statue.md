---
date: 2022-10-28
tags: Session/Strahd
---
# Untitled
**Date:** 2022-10-28
**Location:** [[Amber Temple]] 
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Zedifur]] - [[Bryan]]


## Events
Continuing on at the [[Amber Temple]]. GM says we do not need Paul at all. We pull a rabbit (Zedifur) our of our hat.

Carric scouts ahead.

### Amber Golem Room
*The walls and ceiling in the eastern portion of this bare stone room have collapsed. To the west and south are open amber doors. In the center of the room is a ten-foot-tall statue of a jackal-headed warrior made of cracked amber. *

There is an [[Golem, Amber|Amber Golem]] inert, but likely guarding the area.

### East Amber Room
Decide to explore more before taking on the Golem. Head south and are accosted by green [[Flameskull|Flameskulls]], coming out of the hole. Zed Flamestrikes the group. Carric closes and attacks one, and hits. Kas closes as well, striking. Flameskulls miss, and one goes blurry.

Zed miss the blurry one. Carric attacks the blurry skull and hits! Destroys the skull. He also hits his original target. Kas stabs hard into another. The Skulls fire rays at us, generally missing. One partially hits Carric.

Zed strikes with Guiding Bolt, granting Advantage on the skull on Carric. Carric strikes and destroys the one in front of him. Kas misses. Last Skull drops a nuked at ground zero. Carric dives away, Kas resists (saves), and the skull is immune.

Zed launches Guiding Bolt again, but GM cheats by using a Shield reaction but still grants Adv. Carric finishes him. Kas kicks the skulls into the hole as a warning to others.

### Giant Statue Rooom
Right hand side across the room:
*This black marble balcony, thirty feet above the floor, overhangs the northeast corner of the temple. The two amber doors leading from this balcony stand open.*

Right hand side across the room:
*This black marble balcony overhangs the northwest corner of the temple, the floor of which lies thirty feet below. Nearly half of the balcony has fallen away, and obvious cracks have formed near its ragged edge.*

#### Temple Main Floor
*Four black marble columns support the vaulted ceiling of the temple, at the north end of which stands a forty-foot-tall statue of a cowled figure in flowing robes. The statue's stony hands are outstretched as if in the midst of casting a spell. Its face is a void of utter blackness.*

*The ominous statue stands between two black marble balconies, one of which has partially collapsed and fallen on the temple's black marble floor, in front of an open doorway. The walls of the temple are sheathed in amber, and the doors leading from it are made of amber as well. Arched hallways coated with amber lead away from the temple to the west and east. Flanking these exits are alcoves that hold white marble statues of robed human wizards with pointed hats and golden staffs. One of them has toppled over and lies shattered on the floor.*

We go down to the temple floor. From the giant statue, a fireball comes from its darken Cowl. We rush forward to try to get cover. Kas gets to the foot of the statue. Then Misty Step up to the cowl, and feels around. It does feel like a face. Carric climbs. Zed still looking about the floor area.

Kas feels around to strike and eye, but finds a hole. For a second, feel like paralysis but resists. There is  a room in the head, it still very dark. But, she is not alone...

Zed comes over to the statue. Carric gets into the head. Kas strikes, missing due to darkness and Shield. [[Henrich Stolt]] tries Fear (we do not know the name yet). Carric gets in and slips a dagger into him, but its not much of an impact. Kas continues to strike close. Henrich calls upon electrical energy. Nasty damage to Kas (saves, but still high). Carric dodges.

Cliffhanger!











##### Navigation
[[CoS 14 - Amber Temple]]  | [[Curse of Strahd]] | [[CoS 16 - Even More Amber Temple]]

