
---
date: 2022-08-12
tags: Session/Strahd
---
# Session 6 - The Wizard of Wines 
**Date:** 2022-08-12
**Location:**
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Zedifur]] - [[Bryan]]

## Events
### Location:  [[Vallaki]], [[Vallaki#Blue Water Inn|Blue Water Inn]]
Level up! Level 4! No Paul tonight.

A half-elf name [[Rictavio]] comes down the stairs. [[Brom Martikov]], that little cheater, fawns all over him. He introduces himself. He is a bard and likes to tell tales. But he pretty much ignores [[Ismark the Lesser]] and [[Ireena Kolyana]]. Seems kinda nosey to Kas. There are a few others about tonight (9 others). He has not seen my people. From Darkon. He then goes off and tells a boring story.

He has the wagon we saw coming in.
![[Vallaki#Rictavio's Carnival of Wonders]]

Then 2 men come in together - [[Szoldar Szoldarovich]] and [[Yevgeni Krishkin]] - hunters.

We talk plans, likely to head out in the morning to the [[Abbey of Saint Markovia]]. Should take us about half a day to get there.

Next day - looks like one small celebration came down, another going up. 

### On the Road
>[!note] Crossroad
>The road comes to an X intersection, with branches to the northwest, northeast, southwest, and southeast. The lower half of a snapped wooden signpost thrusts upward at an angle near the eastern elbow of the intersection. The top half of the sign, featuring arms pointing in four directions, lies in the weeds nearby.

- NE to Lake Baratok
- NW  to Castle Ravenloft
- SE to 
- SW to [[Krezk]] 

Another intersection with a sign to [[Wizard of Wines]]

### Krezk 
>[!info] Krezk 
>The road branches north and climbs a rocky escarpment, ending at a gatehouse built into a twenty-foot-high wall of stone reinforced with buttresses every fifty feet or so. The wall encloses a settlement on the side of a snow-dusted mountain spur. Beyond the wall you see the tops of snow-covered pines and thin, white wisps of smoke. The somber toll of a bell comes from a stone abbey that clings to the mountainside high above the settlement. The steady chime is inviting - a welcome change from the deathly silence and oppressive fog to which you have grown accustomed. It's hard to tell at this distance, but there seems to be a switchback road clinging to the cliffs that lead up from the walled settlement to the abbey.

To the gatehouse 

>[!info] Gatehouse 
>The air grows colder as you approach the walled settlement. Two square towers with peaked roofs flank a stone archway into which is set a pair of twelve-foot-tall, ironbound wooden doors. Carved into the arch above the doors is a name: Krezk.
>
The walls that extend from the gatehouse are twenty feet high. Atop the parapet you see four figures wearing fur hats and clutching spears. They watch you nervously.

Not much movement on the walls. A few in russian fur hats. We seek entry to the Abbey, they go get the [[Baron Brezkov]]. They will let us in if we get a wagon of wine from the [[Wizard of Wines]].

### Wizard of Wines 
>[!note] Wizard of Wines 
>After a half mile, the road becomes a muddy trail that meanders through the woods, descending gradually until the trees part, revealing a mist-shrouded meadow. The trail splits. One branch heads west into the valley, and the other leads south into dark woods. A wooden signpost at the intersection points west and reads, "Vineyard."
>
>A light drizzle begins to fall. Unpainted fences blindly follow the trail, which skirts north of a sprawling vineyard before bending south toward a stately building. The fog takes on ghostly forms as it swirls between the neatly tended rows of grapevines. Here and there, you see rope-handled half-barrels used for hauling grapes. North of the trail is a large stand of trees. A man wearing a dark cloak and cowl stands at the edge of the trees, beckoning you.

Zed notices others - there are nine other in the mist. A bunch of humans in cloaks. [[Davian Martikov]] runs the place. Evil driuds attacked. There are three barrels you can have if you get rid of the druids.

**Quest - Kill The Druids**

### Winery
Situated in the midst of the vineyard, the winery is an old, two-story stone building with multiple entrances, thick ivy covering every wall, and iron fencing along its roofline. The trail ends at an open loading dock on the ground floor.

A wooden stable of more recent construction is attached to the east side of the winery, next to the loading dock. West of the winery is a crumbling well and a wooden outhouse.

We go towards the wagon bay, we are attacked by vine-line creatures ([[Blights|Groots]]). Kas calls upon [[Vulkoor]] (Shield of Faith) and shoots one with a hand crossbow. We take some shots and set up to defend the wagon. They swarm us. 

As we battle, someone comes out of the building into the wagon bay. Carric somehow manages to hide from them. They cast some power to grant protection (barkskin). Carric sneak attacks him! Hits him with the bonus action attack. Some damage. That drops his Barkskin. 

Ireena is hurt pretty badly as we slowly cut down the Blights. Zed hits with Guilding Bolt on the druid (the man that appeared). Does damage and grants advantage. Carric then guts the druid and closes the door.

We end mid battle! To Be Continued


##### Navigation
 [[CoS 05 - On the Road]]| [[Curse of Strahd]] | [[CoS 07 - Battle of the Blights]] 

