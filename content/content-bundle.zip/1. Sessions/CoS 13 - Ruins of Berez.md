---
date: 2022-10-14
tags: Session/Strahd
---
# COS 13 - The Next Thing
**Date:** 2022-10-14
**Location:**
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Nyx]] - [[Ippolito, Paul]]
- [[Zedifur]] - [[Bryan]]


## Events
Back in [[Vallaki]] at the [[Saint Adral's Church]] after recovering [[Tome of Strahd]]. Now, to the Villiage Drown in Water. The priest things this must be the ruin village of [[Berez]] off the [[Luna River]]. Avoided due to evil feel.

### Vision in a Dream for Kas.
See through someone else eyes, in some dank dungeon. Probably in the castle. See a handsome man, fine clothes. But clothes are aged. The man looks handsome but ancient is some way. Must be [[Strahd von Zarovich]] . Can feel the body is in extreme pain, shackled. A dark elf. Strahd is talking to them - monologuing. Is asking about another female elf (likely Kas). Somehow, they are projecting to me, sharing this. Its [[Alaundril Zolond]], Priestess of Vulkoor. "It is the will of [[Vulkoor]]"

### To Berez 
*The dirt and grass soon turn to marsh as the trail dissolves into spongy earth pockmarked with stands of tall reeds and pools of stagnant water. A thick shroud of fog covers all. Scattered throughout the marsh are old peasant cottages, their walls covered with black mildew, their roofs mostly caved in. These decrepit dwellings seem to hunker down in the mire, as though they have long since given up on escaping the thick mud. Everywhere you look, black clouds of flies dart about, hungry for blood.*

*The fog is much thinner on the far side of the river, where a light flashes amid a dark ring of standing stones.*

Someone seems to flashing a light in our direction across the river by the standing stones. Zedifur finds a great place to cross the river. 


![[Berez#Menhirs]]
[[Muriel Vinshaw]] is one of the souled. Looks to be [[County of Barovia|Barovian]], and not [[Vistani]]. An ancient and powerful hag named Baba Lysaga lives in a hut in the middle of the village. When not in her hut, [[Baba Lysaga]] flies around in a giant skull. Baba Lysaga periodically sends her scarecrows to attack the Wizard of Wines, a winery and vineyard west of Berez. 

![[Berez#Church]]
Nothing here of interest.
![[Berez#The Mansion]]
We avoided.
![[Berez#The Statue]]

Carric looks around the statue. There is an oddity around the base. Carric digs around and pulls out some an amulet - the [[Holy Symbol of Ravenkind]]. Then creatures rise up out of the mire ([[Zombie|Zombies]]?). We outpaced them. The old lady is gone, but her stuff is there (set down).

Back to [[Vallaki]].




##### Navigation
 [[CoS 12 - The Wizard's Tower]]| [[Curse of Strahd]] | [[CoS 14 - Amber Temple]]

