---
date: 2022-07-29
tags: Session/Strahd
---
# Session 5 - On The Road
**Date:** 2022-07-29
**Location:**
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Nyx]] - [[Ippolito, Paul]]
- [[Zedifur]] - [[Bryan]]

## Events
Nyx and Zed wandering the woods northeast of [[Barovia]] looking for Fey.

>[!danger] An Encounter
>A gaunt figure with wild hair and bare feet bounds toward you on all fours, wearing a tattered gown of stitched animal skins. You can't tell whether it's a man or a woman. It stops, sniffs the air, and laughs like a lunatic. The ground nearby is crawling with tiny twig monsters.

Narrate them working through the encounter. While trying to chase them off, they kill this odd druid.

Then,
>[!danger]
>A scarecrow lurches into view. Its sackcloth eyes and rictus are ripe with malevolence, and its gut is stuffed with dead ravens. It has long, rusted knives for claws.

A brutal fight they had to flee from. They go back to Barovia and link up with the real heroes. They try to play it off cool but to not tell us of scarecrows.

We have a map of the [[County of Barovia]]. We head out. Cross a bridge over the [[River Ivlis]].


>[!example] Tser Pool Crosswoods 
>An old wooden gallows creaks in a chill wind that blows down from the high ground to the west. A frayed length of rope dances from its beam. The well-worn road splits here, and a signpost opposite the gallows points off in three directions: BAROVIA VILLAGE to the east, TSER POOL to the northwest, and RAVENLOFT/VALLAKI to the southwest. The northwest fork slants down and disappears into the trees, while the southwest fork clings to an upward slope. Across from the gallows, a low wall, crumbling in places, partially encloses a small plot of graves shrouded in fog.

We avoid the [[Tser Pool]]. We start to leave, there is now a body, and Kas sees the below, but the body is hers.

>[!example] Hanging Body
>You hear a creaking noise behind you, coming from the gallows. Where there was nothing before now hangs a lifeless, gray body. The breeze turns the hanged figure slowly, so that it can fix its dead eyes upon you.

She cuts the body down, but it dissolves. Onward.

Later, 
>[!example] Skeletal Rider
>Through the mist comes a skeletal warhorse and rider, both clad in ruined chainmail. The skeletal rider holds up a rusted lantern that sheds no light.

We avoid and it ignores us.
>[!example] Waterfall & Bridge
>You follow the dirt road as it clings to the side of a mountain and ends before an arching bridge of mold-encrusted stone that spans a natural chasm. Gargoyles cloaked in black moss perch on the corners of the bridge, their frowns weatherworn. On the mountainous side of the bridge, a waterfall spills into a misty pool nearly a thousand feet below. The pool feeds a river that meanders into the fog-shrouded pines that blanket the valley.


>[!example] Crosswoods to Castle Ravenloft
>Even here, in the mountains, the forest and the fog are inescapable. Ahead, the dirt road splits in two, widening toward the east. There you see patches of cobblestone, suggesting that the eastern branch was once an important thoroughfare.

Past this is another set of giant gates.


![](https://i.imgur.com/q48QGbK.png)

Bummer, no giants.

We come upon some sort of Fey - a corpse. Carric thinks it looks like Nyx, but Zed does not. Nyx is stunned by it - it was ravaged by animals. But all of us can see this, whereas previously the other did not think the body was Kas.

Kas goes to behead it with her kukri knife, but it dissolves as well. Zed prays.

Approach [[Lake Zarovich]] and [[Vallaki]], while seeing the [[Old Windmill]] on the way (*we do not stop*)

>[!example] Windmill and [[Lake Zarovich]] 
>The Old Svalich Road transitions here from being a winding path through the Balinok Mountains to a lazy trail that hugs the mountainside as it descends into a fog-filled valley. In the heart of the valley you see a walled town near the shores of a great mountain lake, its waters dark and still. A branch in the road leads west to a promontory, atop which is perched a dilapidated stone windmill, its warped wooden vanes stripped bare.

## Vallaki 
Arrive at [[Vallaki]] 


![](https://i.imgur.com/E7wcJkj.jpg)

We arrive just as the gates are about to close. They have many warnings against wolves. The gate is wrought iron. Kas convinces them to let us in.

There is just more color here. Animals are kept inside. The guards are false nice.
 There are some happy folk around, the more happy the more color. Although [[Ismark the Lesser|Ismark Kolyana]]  and [[Ireena Kolyana]] have color but they are not happy.


![[Vallaki#Blue Water Inn]]


Red Dragon Crush wine, Wolf steak. Kas is bad with numbers. An Abbott / Costello routine breaks out over the money. 

##### Navigation
 [[CoS 04 - 0Barovia]]| [[Curse of Strahd]] | [[CoS 06 - Wizard of Wines]]

