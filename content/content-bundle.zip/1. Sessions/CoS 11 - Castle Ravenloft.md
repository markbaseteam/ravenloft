---
date: 2022-09-23
tags: Session/Strahd
---
# Session - CoS 11 - Castle Ravenloft
**Date:** 2022-09-23
**Location:**
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Nyx]] - [[Ippolito, Paul]]
- [[Zedifur]] - [[Bryan]]
- [[Bloodstone, Jasper]] - [[Lonnie]] 

## Events

Into the Carriage that might lead us to [[Castle Ravenloft]].

*After winding through the forest and craggy mountain peaks, the road takes a sudden turn to the east, and the startling, awesome presence of Castle Ravenloft towers before you. The carriage comes to a dead stop before twin turrets of stone, broken from years of exposure. Beyond these guard towers is the precipice of a fifty-foot-wide, fog-filled chasm that disappears into unknown depths.

*A lowered drawbridge of old, shored-up wooden beams stretches across the chasm, between you and the archway to the courtyard. The chains of the drawbridge creak in the wind, their rust-eaten iron straining under the weight. From atop the high walls, stone gargoyles stare at you out of their hollow eye sockets and grin hideously. A rotting wooden portcullis, green with growth, hangs above the entry tunnel. Beyond this location, the main doors of Ravenloft stand open. A rich, warm light spills from within, flooding the courtyard. Torches flutter sadly in sconces on both sides of the open doors*.

![](https://i.imgur.com/p73jK6X.png)

*Thick, cold fog swirls in this courtyard. Sporadic flashes of lightning lance the weeping clouds overhead as thunder shakes the ground. Through the drizzle, you see torch flames fluttering on each side of the keep's open main doors. Warm light spills out of the entrance, flooding the courtyard. High above the entrance is a round window with shards of broken glass lodged in its iron frame.*

*The ornate outer doors of the castle hang open, flanked by fluttering torches in iron sconces. Twenty feet inside the castle is a second set of doors.*

The group advances in, Kas seeks her people. There is gothic organ music playing.

*Cobwebs stretch between the columns that support the vaulted ceiling of a great, dusty hall dimly lit by sputtering torches in iron sconces. The torches cast odd shadows across the faces of eight stone gargoyles squatting motionlessly on the rim of the domed ceiling. Cracked and faded ceiling frescoes are covered by decay.*

*Double doors of bronze stand closed to the east. To the north, a wide staircase climbs into darkness. A lit hallway to the south contains another set of bronze doors, through which you hear sad and majestic organ tones.*

[[Rahadin]] lets us in.

### Dining Hall
*Three enormous crystal chandeliers brilliantly illuminate this magnificent chamber. Pillars of stone stand against dull white marble walls, supporting the ceiling. In the center of the room, a long, heavy table is covered with a fine white satin cloth. The table is laden with many delectable foods: roasted beast basted in a savory sauce, roots and herbs of every taste, and sweet fruits and vegetables. Places are set for each of you with fine, delicate china and silver. At each place is a crystal goblet filled with an amber liquid with a delicate, tantalizing fragrance.*

*At the center of the far west wall, between floor-to-ceiling mirrors, stands a massive organ. Its pipes blare out a thunderous melody that speaks in its tone of greatness and despair. Seated at the organ, facing away from you, a single caped figure pounds the keys in raptured ecstasy. The figure suddenly stops, and as a deep silence falls over the dining hall, it slowly turns toward you.*

![](https://i.imgur.com/aMQ3j8D.png)


It is [[Strahd von Zarovich]] 

He confuses Kas as she searches for his people. Clearly, he know they are here and he has some purpose for them, likely foul. But he does give us free reign of the place, but the castle seals itself.

In the courtyard, oddly it appears open. But Carric does find the yin/yang scorpion amulet of [[Nadus Chaulssar]], the leader of the tribe.

On looking around instead of leaving - Dumb ideas is what got us here today (Nyx).

### Grand Hall
Go back in, to the double doors. Hallway of statues. Leads to a ruined chapel to the Morninglord.

### Chapel
*Dim, colored light filters through tall, broken, and boarded-up windows of stained glass, illuminating the ancient chapel of Ravenloft. A few bats flutter about near the top of the ninety-foot-high domed ceiling. A balcony runs the length of the west wall, fifty feet above the floor. In the center of the balcony, two dark shapes are slumped in tall chairs.*

*Benches coated with centuries of dust lie about the floor in jumbled disarray. Beyond this debris, lit by a piercing shaft of light, an altar stands upon a stone platform. The sides of the altar are carved with bas-reliefs of angelic figures entwined with grape vines. The light from above falls directly on a silver statuette. A cloaked figure is draped over the altar, and a black mace lies on the floor near its feet.*

By the guy is a [[Mace of Terror]].
![](https://i.imgur.com/zmo7P3n.png)

Also find

![](https://i.imgur.com/NsXHwft.png)

The dead guy has burns likely from radiant damage on him. Likely grabbing the statuette got him. Zedifur is able to touch it, it has a bit of a charge. There is a power for Good there.

[[Icon of Ravenloft]]

We grab the cloak (party sheet) and the mace (Jasper). The Mace is magic. 

### Chapel Balcony
*A sculpted stone railing encloses this long balcony, which overlooks Ravenloft's chapel. Two ornate thrones stand side by side in the center of the balcony, covered with dust and strung with cobwebs. The thrones face away from the double doors that give access to the balcony.*

Carric asks Kas if there is a way to contact her people. She things really hard, and thinks she could sense another object that might be on other familiar people (Locate Object). Kas would need to prepare the spell.


#### Zombie Attack

<div class="FullPage">

<!--container for image and iframe -->
<div style="float:right; margin-left:20px">
<img src="https://i.imgur.com/KvNsyMQ.png" height="275" align="right"><br>
</div>

 [[Zombie|Zombies]] rise up.  Jasper hits on one of them. Zed turns one of them. These of the Strahd variety and are of weaker stuff (limbs fall off). But wait, the disembodied arm also attacks! Then we finish off the other one.

### Hallway 
Open the double doors, hear moans. Advance and a vampire attacks!
Kas slays the mechanical vampire!

### Audience Hall
*Dim light from the courtyard falls into this great hall through the broken glass and iron latticework of a large window in the west wall. This immense room is a place of chilly, brooding darkness. Empty iron sconces dot the walls. Hundreds of dust-laden cobwebs drape the hall, hiding the ceiling from view. Directly across from the window stand a set of double doors in the east wall. Farther south, a single door also leads from the east wall. Staircases at both ends of the north wall lead down.*

*At the far southern end of the hall, a large wooden throne stands atop a marble dais. The high-backed throne faces south, away from most of the room.*

### Study
Dusty scrolls and tomes line the walls of this room. More scrolls and books lie scattered on the floor, around four heavy wooden chests fitted with study iron locks. The only unobstructed floor space is directly in front of the doors on the east and west walls.

In the center of this clutter stands a great black desk. A figure crouches atop a tall stool, scratching on a seemingly endless scroll of paper with a dry quill pen. Nearby a tasseled rope hangs from a hole in the ceiling.


See an old man - [[Lief Lipsiege]]

![](https://i.imgur.com/RqbjSFy.png)

Note: he is chained to the desk. Has not seen Drow.
In the catacombs or depths of the castle, but has noted no increase in cost. He has done a good number of the books and scrolls. As from the village of [[Barovia]].

We explore a bit more and decided to exit the castle for now. Back to [[Vallaki]] and to the church.


##### Navigation
[[CoS 10 - The Reading]] | [[Curse of Strahd]] | [[CoS 12 - The Wizard's Tower]]

