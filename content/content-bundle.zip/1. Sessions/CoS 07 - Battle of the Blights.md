---
date: 2022-08-19
tags: Session/Strahd
---
# Session 7 - Battle of the Blights
**Date:** 2022-08-19
**Location:** [[Wizard of Wines]] 
## PCs
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- [[Carric]] - [[Daymude, Mark]]
- [[Nyx]] - [[Ippolito, Paul]]
- [[Zedifur]] - [[Bryan]]

## Events

### Blight Battle
We pick up in the middle of a fight. [[Ismark the Lesser]] is taking a beating as we still tear down these [[Blights|Needle Blights]].  Zedifur notices a winch over the wagon. Tucked up there is another druid. He just seems to be watching. Carric does not him as he hears more activity from inside the brewery. He tries to shut and seal the door. 

While Carric sealed the door, something rips open the door. Something even more plant-like steps through - a [[Blights|Vine Blight]]. There is another behind him. Carric sneak attacks him, cutting him down. Handing in there, Ismark is thinking the blights. 

A couple of people hear the druid on the wench say something in an obscure language in a not nice way, rans off (maybe invisible). One of the Vine Blights extends vines, entangling [[Ireena Kolyana]] but Zed avoids.

The birth of the [[Mimic|Barrel Mimic]].

This wild druid woman steps up and drops some form of boom spell, hitting Kas, Nyx, and Zed. Carric gives her the business (critical hit), killing her. We catch our breath before going in.

### Winery Ground Floor

#### Turret Room
*This turret has a sloping, wooden floor that spirals from the cellar to the upper levels. Scratch marks suggest that barrels are rolled up and down the ramp on a routine basis.*

#### Vat Room
*The rich smell of fermenting wine fills this large, two-story chamber, which is dominated by four enormous wooden casks, each one eight feet wide and twelve feet tall. A wooden staircase in the center of the room climbs to a ten-foot-high wooden balcony that clings to the south wall, which has four windows set into it at balcony level. Stacked against the wall underneath the balcony are old, empty barrels with "The Wizard of Wines" burned into their sides. The balcony climbs another five feet as it continues along the west and east walls, ending at doors leading to the winery's upper level. Underneath these side balconies are several doors, some of which hang open. Beneath the sloping roof stretch thick rafters, upon which scores of ravens have quietly gathered. They watch you with great interest.*


#### Empty Barrel Room & Workshop
*Rows of new barrels fill this room. A narrow stone staircase spirals upward in the southwest corner.*

*Strips of iron and wood lie in neat piles on the floor of this workshop, the walls of which are lined with tools. Two worktables stand against the east wall.*

#### Locked Veranda
Carric picks a padlock.

*Resting on a flagstone veranda are three five-foot-diameter wooden tubs, their insides stained with grape juice. Each tub has a short ladder bolted to its side and a catch basin tucked underneath.*

*At the back of the veranda is a large set of sliding wooden doors as well as a normal-sized wooden door. Stone pillars and arches support the upper floor above.*

#### Broken Side Door
*Bare hooks line the walls of this storage room. Shelves to the south hold several pairs of stained wooden sandals with oversized soles. Both doors to this room hang open. The one to the west is fitted with iron brackets and leads outside into the rain. Lying on the floor next to it is a five-foot-long wooden beam.*

#### West Turret
*This turret contains a stone spiral staircase. Windows in the outer wall allow light to enter.*

#### South Exit
*A dirty window in the south wall allows dim light to enter this room. Wine bottles are manufactured here, as evidenced by the tools lying about, the wooden rack full of freshly blown glass bottles along the south wall, the hearth built into the southwest corner, and the barrel of sand standing next to it. A staircase descends underground, and between it and the rack of bottles stands a barred door.*

### Winery Basement
Down the central staircase.

*Wooden pillars and beams support the ten-foot-high ceiling of this ice-cold cellar, which is split in two by a five-foot-thick brick wall. A thin mist covers the floor. Each half of the cellar features an eight-foot tall wooden partition that doubles as a wine rack. The western rack stands empty, but the eastern one is half filled with wine bottles.*

*Something moves behind the eastern wine rack. Through the holes, you glimpse a half dozen humanoid figures, one with a full rack of antlers. You hear a gravelly voice mutter the words of a spell.*

Nyx casts protection from good/evil on Kas. Kas comes into the room, comes around the rack, and finally hits with her whip. She hits the druid that is chanting in the back. Somehow, Kas gets the count right of the enemies behind the rack and shouts it out. Carric comes around to attack and [[Blights| Needle Blight]], slaying it. Zeb drops sacred flame to no avail. 

One of the blight shoots needles at Kas. It misses, but another rakes Kas. More missed needles at Kas, as she dances around behind her shield. The druid moves away (but takes another lash from Kas) and drops a spell on Ismark, Ireena, and Zed in a thunder wave. Zed is not braced for it (stunned that Kas is hitting with the whip) and is slammed into a back wall. 

Nyx comes in and blasts one of the blights. Leaning into her Oath of Vengeance, Kas comes around, nimbly dodges a Blight, and strikes down the druid!

>[!quote]
>Your foul neutrality ends here!

The blights remain, we whittle them down. Get it? Whittle down plant creatures. Carric gets another critical hit, taking another one out. Zed mops the last one.

We saved most of the bottles! Red Dragon Crush! There are three barrels of purple grape mash number three.

We recover the promised wine shipment. Carric does poke around a bit, more for information. They are the main distributor for the area taverns, add [[Strahd von Zarovich]] himself!

The druid that fled is not found. [[Davian Martikov]] is appreciative, but tries to have us recover magic seeds.

- One taken long ago
- One by the druids
- One by Baba Yaga

Decline the immediate quest as we must secure Ireena, but we do say we might look into it. Wine is on its way to [[Krezk]].

##### Navigation
[[CoS 06 - Wizard of Wines]] | [[Curse of Strahd]] | [[CoS 08 - Abby of Saint Markovia]]

