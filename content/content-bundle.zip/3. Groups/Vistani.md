# Vistani

Rumor is they helped [[Strahd von Zarovich]] before he became a vampire. [[Ismark the Lesser]] things they are all servants of Strahd. Rumored they can leave [[Barovia]] .

[[Madame Eva]] seems to be independent. 