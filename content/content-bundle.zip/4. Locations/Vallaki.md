---
tags: Location/Strahd Community/Vallaki 
---

# Vallaki

## Description
South/middle shore of [[Lake Zarovich]].

This down has more color than [[Barovia]], less bled out. More natural smells of animals, a town. Animals are kept inside.

![](https://i.imgur.com/E7wcJkj.jpg)

## Locations 

![[Arasek Stockyards#Arasek Stockyards]]

![[Blue Water Inn#Blue Water Inn]]

![[Saint Adral's Church#Saint Adral's Church]]

![[Rictavio's Carnival of Wonders#Rictavio's Carnival of Wonders]]
## NPCs
Brom - Child at the Blue Water Inn.

[[Baron and Baroness of Vallaki]]