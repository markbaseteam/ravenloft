---
tags: Location/Strahd
---

# Abbey of Saint Markovia

*The switchback road that hugs the cliff is ten feet wide and covered with loose gravel and chunks of broken rock. The ascent is slow and somewhat treacherous, and the air grows colder as one nears the top.*

*The road from the village climbs above the mist to the wide ledge on which the abbey is perched. A light dusting of snow covers the trees and the rocky earth.*

*The gravel road passes between two small, stone outbuildings, to either side of which stretches a five-foot-high, three-foot-thick wall of jumbled stones held together with mortar. Blocking the road are iron gates attached to the outbuildings by rusty hinges. They appear to be unlocked. Viewed through the gates, the stone abbey stands quiet. Its two wings are joined by a fifteen-foot-high curtain wall. A belfry protrudes from the rooftop of the closer north wing, which also sports a chimney billowing gray smoke.*

*Stunted pine trees grow out of the rocky earth in the graveyard near the foundation of the abbey's north wing. The windows of the structure are cracked panes of leaded glass. Ancient gravestones burst from a thin crust of snow in the yard. Beyond the low wall that surrounds the graveyard, the ground falls away. The village lies four hundred feet below, and the view is breathtaking.*

*A fifteen-foot-high curtain wall joins the abbey's two wings. Behind its battlements, two guards stand at attention, their features obscured by fog. Below them, set into the wall, is a pair of ten-foot-tall, wooden doors reinforced with bands of steel. To the right of these doors, mounted on the wall, is a tarnished copper "May her light cure all illness."*

## Description
In [[Krezk]] 

Seems to be a save haven for those who have been corrupted. They are dedicated to the Morninglord. This plan is rather messed up. The abbott created a [[Golem, Flesh]] as a bridge for [[Strahd von Zarovich]]. 


## NPCs
- [[The Abbott]]
- [[Vasilka]]
- [[Belview, Otto]] 
- [[Belview, Zygfrek]] 