---
tags: Location/Strahd
---

# Mount Baratok

*Flavor Text*

## Description


## NPCs