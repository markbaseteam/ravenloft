---
tags: Location/Strahd Community/Vallaki 
---

# The Saint Adral's Church

## Description

### Saint Adral's Church 
This slouching, centuries-old stone church has a bulging steeple in the back and walls lined with cracked, stained glass windows depicting pious saints. A fence of wrought iron encloses a garden of gravestones next to the church. A thin mist creeps among the graves.

Church of the Morninglord. [[Father Lucian Petravich]] presides.

### Relic 
![[Bones of Saint Adral]] 
