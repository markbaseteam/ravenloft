---
tags: Location/Strahd Geography/River
---

# River Ivlis

*Flavor Text*

## Description


## NPCs