---
tags: Location/Strahd Community/Vallaki
---

# The Blue Water Inn

*Flavor Text*

## Description



### Blue Water Inn
>[!example] Outside the Inn
>Gray smoke issues from the chimney of this large, two-story wooden building with a stone foundation and sagging tile roof, upon which several ravens have perched. A painted wooden sign hanging above the main entrance depicts a blue waterfall.

>[!Example] Inside the Inn
>Damp cloaks hang from pegs in the entrance portico. The tavern is packed with tables and chairs, with narrow paths meandering between them. A bar stretches along one wall, under a balcony that can be reached by a wooden staircase that hugs the north wall. Another balcony overhangs an entrance to the east. All the windows are fitted with thick shutters and crossbars. Lanterns hanging above the bar and resting on the tables bathe the room in dull orange light and cast shadows upon the walls, most of which are adorned with wolf heads mounted on wooden plaques.

The bartender is in between in is vibrancy. 

[[Brom Martikov]] is the child service. His mother is at the bar talking with the innkeeper. Martikov family.

#### Menu
**Drink**
- Red Dragon Crush 
- Purple Grapemash 3

**Food**
- Beet Soup 
- Purple Grapemash
- Wolf Steak

