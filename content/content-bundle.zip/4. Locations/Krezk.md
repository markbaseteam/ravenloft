---
tags: Location/Strahd
---

# Krezk

*The road branches north and climbs a rocky escarpment, ending at a gatehouse built into a twenty-foot-high wall of stone reinforced with buttresses every fifty feet or so. The wall encloses a settlement on the side of a snow-dusted mountain spur. Beyond the wall you see the tops of snow-covered pines and thin, white wisps of smoke. The somber toll of a bell comes from a stone abbey that clings to the mountainside high above the settlement. The steady chime is inviting - a welcome change from the deathly silence and oppressive fog to which you have grown accustomed. It's hard to tell at this distance, but there seems to be a switchback road clinging to the cliffs that lead up from the walled settlement to the abbey.*

## Insider Krezk
*The mist-shrouded village beyond the wall is nothing more than a scattering of humble wooden cottages along dirt roads that stretch between stands of snow-dusted pine trees - so many trees, in fact, as to constitute a forest. To the northeast, gray cliffs rise sharply, and the road winding up to the abbey is easy to see from this vantage.*

Note - there are no businesses - its like a hippy commune.

## Description

![](https://i.imgur.com/lSMEwNf.jpg)

![](https://i.imgur.com/GWZ4OsV.png)


## NPCs
- [[Baron Brezkov]] 
- People in the [[Abbey of Saint Markovia]] 