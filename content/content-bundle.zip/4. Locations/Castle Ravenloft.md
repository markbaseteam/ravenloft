---
tags: Location/Strahd
---

# Castle Ravenloft

*Flavor Text*

## Description


![](https://i.imgur.com/p73jK6X.png)

![](https://i.imgur.com/dRND266.png)

## NPCs