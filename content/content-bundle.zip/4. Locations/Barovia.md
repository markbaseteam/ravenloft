---
tags: Location/Strahd
---

# Barovia
The main village in the county of Barovia.

![](https://i.imgur.com/Nln3FnI.jpg)

Death House

The sparse light from this building spills out from behind drawn heavy curtains. A sign over the door, creaking on its hinges, reads "Bildrath's Mercantile." (SE of main square). [[Bithrath]]

Blood on the Vine Tavern - due north from Mercantile

