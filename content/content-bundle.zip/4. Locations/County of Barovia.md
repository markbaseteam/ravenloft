---
aliases: Barovian
tags: Location/Strahd
---

# County of Barovia

*Flavor Text*

## Description

## Map
![](https://i.imgur.com/kpiSw9t.jpg)



## NPCs