---
tags: Location/Strahd Geography/River 
---

# Tser Pool

*Flavor Text*

## Description
The [[Vistani]] hang out there. [[Ismark the Lesser]] recommends to avoid

Crossroads on [[The Way Inn]] 
>[!Info]
>An old wooden gallows creaks in a chill wind that blows down from the high ground to the west. A frayed length of rope dances from its beam. The well-worn road splits here, and a signpost opposite the gallows points off in three directions: BAROVIA VILLAGE to the east, TSER POOL to the northwest, and RAVENLOFT/VALLAKI to the southwest. The northwest fork slants down and disappears into the trees, while the southwest fork clings to an upward slope. Across from the gallows, a low wall, crumbling in places, partially encloses a small plot of graves shrouded in fog.

*The road gradually disappears and is replaced by a twisted, muddy path through the trees. Deep ruts in the earth are evidence of the comings and goings of wagons.

*The canopy of mist and branches suddenly gives way to black clouds boiling far above. There is a clearing here, next to a river that widens to form a small lake several hundred feet across. Five colorful round tents, each ten feet in diameter, are pitched outside a ring of four barrel-topped wagons. A much larger tent stands near the shore of the lake, its sagging form lit from within. Near this tent, eight unbridled horses drink from the river.*

*The mournful strains of an accordion clash with the singing of several brightly clad figures around a bonfire. A footpath continues beyond this encampment, meandering north between the river and the forest's edge.*

## NPCs
[[Madame Eva]] 
[[Vistani]] 