---
tags: Location/Strahd
---

# Van Richten's Tower


## Description
![](https://i.imgur.com/CQcymNP.png)



### Tower of Van Richten 
*The tower door is made of iron, with no visible handles or hinges. In the middle of the door is a large, embossed symbol - a connected series of lines with eight stick figures set around it. Carved into the lintel above the door is a word: KHAZAN.*

![](https://i.imgur.com/7fa4QOk.jpg)


### NPCs