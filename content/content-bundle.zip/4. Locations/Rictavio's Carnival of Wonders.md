---
tags: Location/Strahd Community/Vallaki 
---

# The Reknown Rictavio's Carnival of Wonders


## Description

### Rictavio's Carnival of Wonders
Parked at the south end of the stockyard is a sturdy carnival wagon, its colorful paint peeling off. Faded lettering on its sides spells out the words "Rictavio's Carnival of Wonders." A heavy padlock secures the back door.
