---
tags: Location/Strahd Community/Vallaki 
---

# The Arasek Stockyards

*Flavor Text*

## Description

### Arasek Stockyards
This large stockyard has several locked sheds along its periphery and lies adjacent to a roomy warehouse. A wooden sign above the front gate reads "Arasek Stockyard."