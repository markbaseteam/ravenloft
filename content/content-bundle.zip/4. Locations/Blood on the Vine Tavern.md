---
tags: Location/Strahd
aliases: [Blood of the Vine]
---

Blood of the Vine or Blood of the Vine?

In [[Barovia]]

[[Ismark the Lesser]]

There are 3 "vibrant" women sitting together. They are [[Vistani]] and own the inn.

One other vibrant sitting alone.
