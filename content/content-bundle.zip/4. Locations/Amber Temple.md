---
tags: Location/Strahd
---

# The Amber Temple


## Description
*The road fades away under a covering of snow, but it takes you far enough to see the facade of some kind of temple carved into the sheer mountainside ahead. The front of the structure is fifty feet high and has six alcoves containing twenty-foot-tall statues. Each statue is carved from a single block of amber and depicts a faceless, hooded figure, its hands pressed together in a gesture of prayer. Between the two innermost statues is a twenty-foot-tall archway with a staircase leading down.*

### Amber Temple
We think its the site of the [[Sword of Sunlight]]. Must go through [[Tsolenka Pass]] to get there.

### NPCs