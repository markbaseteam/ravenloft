---
tags: Location/Strahd
---

# Old Windmill

*A branch in the road leads west to a promontory, atop which is perched a dilapidated stone windmill, its warped wooden vanes stripped bare.*

## Description
![](https://i.imgur.com/RrBknp0.png)


## NPCs