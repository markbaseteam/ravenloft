---
tags: Location/Strahd
---

# The Berez


## Description
A ruined village that crossed [[Strahd von Zarovich]] off the  [[Luna River]]. 

![](https://i.imgur.com/wJIykVh.jpg)

### Berez
*The dirt and grass soon turn to marsh as the trail dissolves into spongy earth pockmarked with stands of tall reeds and pools of stagnant water. A thick shroud of fog covers all. Scattered throughout the marsh are old peasant cottages, their walls covered with black mildew, their roofs mostly caved in. These decrepit dwellings seem to hunker down in the mire, as though they have long since given up on escaping the thick mud. Everywhere you look, black clouds of flies dart about, hungry for blood.*

*The fog is much thinner on the far side of the river, where a light flashes amid a dark ring of standing stones.*

#### Menhirs
*A dozen moss-covered menhirs form a near-perfect circle in the spongy earth. These weathered stones range in height from 15 to 18 feet. A couple of them lean inward as if to share some great secret with their inscrutable neighbors. A wary-looking peasant woman lurks behind the tallest stone, a rusty lantern clutched in one gnarled hand and a dagger clutched in the other.*

#### The Mansion
*Toward the south end of the village lie the remains of a mansion built on higher ground. It has been reduced to piles of stone and rotting timber. Empty, arched windows stare at you. South of the ruin, an untamed garden runs rampant, surrounded by broken walls that are no longer able to contain it. East of the ruin, someone has erected a crude wooden fence, forming a circular yard in which several goats are penned. Surmounting the fence posts are human skulls.*

#### Church
*Through the fog you see the empty shell an old stone church, north of which is a cemetery of leaning gravestones enclosed by a disintegrating iron fence. Half of the cemetery has sunk into the mire.*


#### Town Square
*Someone has built a ramshackle wooden hut on the stump of what was once an enormous tree. The rotting roots of the stump thrust up from the mire like the legs of a gigantic spider.*

*An open doorway is visible on one side of the hut, beneath which floats the upside-down, hollowed-out skull of a giant. Flanking the hut's doorway are two iron cages that dangle like hideous ornaments from the eaves. Scores of ravens are trapped in each one. They squawk and flutter their wings excitedly as you approach.*

#### The Statue
*Hidden by the fog and elevated a few feet above the surrounding marsh is a raised plot of land, barely ten feet on a side, enclosed by a disintegrating iron fence. In the center of the plot is a life-sized stone monument carved in the likeness of a kneeling peasant girl clutching a rose. Although her features are gray and weatherworn, she bears a striking resemblance to [[Ireena Kolyana]]. Carved into the monument's base is an epitaph. "Marina, Taken by the Mists"* 




### NPCs