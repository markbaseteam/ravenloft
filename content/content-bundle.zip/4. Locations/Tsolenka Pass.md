---
tags: Location/Strahd
---

# The Tsolenka Pass


## Description

<div class="FullPage">

<!--container for image and iframe -->
<div style="float:right; margin-left:20px">
<img src="https://i.imgur.com/wtQAw9X.png" height="275" align="right"><br>
</div>

*One of the statues atop this arch has crumbled, leaving only the hindquarters of the horse intact. The mountain pass continues beyond.*

### Tsolenka Pass


### NPCs