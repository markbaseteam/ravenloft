---
tags: Location/Strahd
---

# Lake Zarovich

*At the foot of a mountain, nestled in the misty forest, is a large lake. The water is perfectly still and dark, reflecting the black clouds overhead like a monstrous mirror.*

## Description
[[Vallaki]] is a town on the south shore.

## NPCs