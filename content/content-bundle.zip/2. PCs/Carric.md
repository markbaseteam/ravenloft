---
tags: PC
---
# Carric

Player: [[Daymude, Mark]]
Elf


![](https://i.imgur.com/yhl0Ors.png)

From Greyhawk Foryndy -0 Prince Thrommel. Out on patrol, got separated in the fog and wound up in Ravenloft.