---
aliases: [Jasper Bloodstone, Jasper]
tags: PC 
---

# Jasper Bloodstone
Earth Genasi
Player: [[Lonnie]] 