---
tags: PC
---
# Nyx
Pixey Warlock, 2'5"
Player - [[Ippolito, Paul]]

![](https://i.imgur.com/lhtyxkL.jpg)


From the Fey - invaded. Made a pact with a Solar for revenge. Has one purple eye and one silver.