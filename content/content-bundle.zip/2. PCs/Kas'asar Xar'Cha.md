

---
aliases: [Kas]
tags: PC
---
# Kas'asar Xar'Cha
Drow Oath of Vengeance Paladin of [[Vulkoor]] from Eberron

Player: [[Rees, Jeffrey]]

![](https://i.imgur.com/PJKFokc.png)

When "Mounted" - "Snips"

### Tribe
Alaundril Zolond, Priestess of Vulkor
Xavin Vrammyr, Volhv (Volhv = shaman - magic would be geared to defend/defeat necromantic magic) Kas has a mentor/difficult pupil relationship with Alaundril. Kas never really took to the religious learnings, but learned enough to be effective. She gravitated to the grim Xavin, who is (was) the point of the spear in both keeping outsiders away from the old giant complex and to destroy any undead the ventured out of it.
    
    ![👍](https://discord.com/assets/08c0a077780263f3df97613e58e71744.svg)
    
    1
    
4.  _[_8:44 AM_]_
    
    Alaundril focused more on the hunter aspect of Vulkoor

![](https://i.imgur.com/Oavyx7H.jpg)

- The number 3 is the most important. Likely because she is too dumb to count any higher

<img src="![](https://i.imgur.com/2vK1noG.jpg)"  
     alt="Markdown Monster icon"  
     style="float: left; margin-right: 10px;" />

![](https://i.imgur.com/2vK1noG.jpg)

### Backstory
1. Her clan's site was a research facility into life and death back in the age of giants, which elves were test subjects.
2. When the giants fell, this place "lived on" with undead and other horrors.
3. Clan vowed to both keep nasty stuff in and deny access to those attracted to such things.
4. Fast forward 40k years, my PC is in training as a guardian.
5. When away for a week for an errand, she came back to the area filled with some strange mist (village and the eeeevil site obscured). Unable to make contact, she gathered supplies and plunged in - to some other place - no sign of the village, no sign of the site - although there was this big castle towering over the lands.
6. She presumes the worst - and is working to exact vengeance and make sure this does not happen to anyone else. Thus, she is on the Vow of Vengeance Paladin path.
