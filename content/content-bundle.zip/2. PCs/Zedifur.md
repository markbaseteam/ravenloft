---
alaises: [Zed, Righteous Rabbit]
tags: PC
---
# Zedifur Briarthorn
Rabbit Guy Cleric of life from Krynn - [[Mishakal]]
Player: [[Bryan]]


![](https://i.imgur.com/xizo7q4.jpg)

Most of his time in a temple. Now on a pilgrimage (Rabbit [[Ulumo Freegrain]]?). Out into the feywild, then wandered into the mist. Now in Ravenloft.