# Curse of Strahd

Start (official kickoff): 2022-06-17

## PCs & Players: 
- [[Daymude, Mark]]
- [[Ippolito, Paul]]
- [[Zedifur]] - [[Bryan]]
- [[Kas'asar Xar'Cha]] - [[Rees, Jeffrey]]
- GM: [[Roy, Shawn]]

